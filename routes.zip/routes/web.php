<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/login', function () {
    return view('login');
});
Route::get('/admin/login', function () {
    return view('admin/login');
});
Route::get('/tmpls/month.html', function () {
    return view('tmpls/month.html');
});
Route::get('/forgot_password', function () {
    return view('forgot_password');
});
Route::get('/admin/forgot_password', function () {
    return view('admin/forgot_password');
});
Route::get('/logout', 'LoginsController@logout');
Route::get('/members/logout', 'LoginsController@membersLogout');
Route::get('/admin/logout', 'LoginsController@adminLogout');

Route::get('/', 'UsersController@index');
Route::get('/about', 'UsersController@about');
Route::get('/terms', 'UsersController@terms');
Route::get('/contact', 'UsersController@contact');

Route::post('/authenticate', 'LoginsController@authenticate');

Route::post('/forgot_password_post', 'UsersController@forgotPasswordPost');
Route::post('/member/forgot_password_post', 'UsersController@memberForgotPasswordPost');

Route::post('/create', 'UsersController@memberRegister');

Route::get('/members/profile', 'MembersController@profile');
Route::post('/members/update_profile', 'MembersController@updateProfile');
Route::post('/members/update_password', 'MembersController@updatePassword');
Route::get('/member/{id_number}', 'MembersController@video');
Route::post('/members/subscribe', 'MembersController@subscribe');

Route::get('/members/visitors', 'MembersController@visitors');
Route::get('/members/appointments', 'MembersController@appointments');
Route::get('/members/new_broadcast', 'MembersController@newBroadcast');
Route::get('/members/broadcasts', 'MembersController@broadcasts');
Route::post('/members/create_broadcast', 'MembersController@createBroadcast');
Route::get('/members/visitor_details/{id}', 'MembersController@visitorDetails');
Route::post('/members/add_note', 'MembersController@addNote');

Route::get('/visitors/member/{member_id}', 'VisitorsController@video');
Route::get('/visitors/register/{id_number}', 'UsersController@visitorsRegister');
Route::get('/visitors/login/{id_number}', 'UsersController@visitorsLogin');
Route::post('/visitors/authenticate', 'LoginsController@visitorsAuthenticate');
Route::post('/visitors/create', 'UsersController@visitorsCreate');
Route::get('/visitors/courses/{id}', 'VisitorsController@courses');
Route::post('/visitors/answer', 'VisitorsController@answer');
Route::post('/visitors/subscribe', 'VisitorsController@subscribe');
Route::get('/visitors/appointments', 'VisitorsController@appointments');
Route::get('/visitors/new_appointment', 'VisitorsController@newAppointment');
Route::post('/visitors/create_appointment', 'VisitorsController@createAppointment');
Route::get('/visitors/comments', 'VisitorsController@comments');
Route::get('/visitors/new_comment', 'VisitorsController@newComment');
Route::post('/visitors/create_comment', 'VisitorsController@createComment');
Route::get('/visitors/info', 'VisitorsController@info');
Route::get('/visitors/forgot_password/{id_number}', 'VisitorsController@forgotPassword');

Route::get('/visitors/profile', 'VisitorsController@profile');
Route::post('/visitors/update_profile', 'VisitorsController@updateProfile');
Route::post('/visitors/update_password', 'VisitorsController@updatePassword');


Route::get('/visitors/certificate', 'VisitorsController@certificate');
Route::get('/visitors/ods', 'VisitorsController@ods');

Route::get('/register', 'UsersController@register');
Route::post('/customer/save', 'UsersController@saveCustomer');


Route::get('/admin', 'AdminsController@index');
Route::get('/admin/index', 'AdminsController@index');
Route::get('/admin/admins', 'AdminsController@admins');
Route::get('/admin/new_admin', 'AdminsController@newAdmin');
Route::get('/admin/edit_admin/{id}', 'AdminsController@editAdmin');
Route::post('/admin/save_admin', 'AdminsController@saveAdmin');
Route::get('/admin/deactivate_admin/{id}', 'AdminsController@deactivateAdmin');
Route::get('/admin/activate_admin/{id}', 'AdminsController@activateAdmin');
Route::get('/admin/profile', 'AdminsController@profile');

Route::get('/admin/plans', 'AdminsController@plans');

Route::get('/admin/new_plan', 'AdminsController@newPlan');
Route::get('/admin/edit_plan/{id}', 'AdminsController@editPlan');
Route::post('/admin/update_plan', 'AdminsController@updatePlan');
Route::post('/admin/save_plan', 'AdminsController@savePlan');

Route::get('/admin/deactivate_plan/{id}', 'AdminsController@deactivatePlan');
Route::get('/admin/activate_plan/{id}', 'AdminsController@activatePlan');

Route::post('/admin/update_profile', 'AdminsController@updateProfile');
Route::post('/admin/update_password', 'AdminsController@updatePassword');

Route::post('/admin/send_certificate', 'AdminsController@sendCertificate');
Route::post('/admin/add_subscription', 'AdminsController@addSubscription');

Route::get('/admin/members', 'AdminsController@members');

Route::get('/admin/new_member', 'AdminsController@newMember');

Route::post('/admin/save_member', 'AdminsController@saveMember');
Route::get('/admin/unregistered_members', 'AdminsController@unregisteredMembers');
Route::get('/admin/deactivate_member/{id}', 'AdminsController@deactivateMember');
Route::get('/admin/activate_member/{id}', 'AdminsController@activateMember');
Route::get('/admin/edit_member/{id}', 'AdminsController@editMember');

Route::get('/admin/reg_member/{id}', 'AdminsController@regMember');

Route::get('/admin/visitors', 'AdminsController@visitors');
Route::get('/admin/deactivate_visitor/{id}', 'AdminsController@deactivateVisitor');
Route::get('/admin/activate_visitor/{id}', 'AdminsController@activateVisitor');
Route::get('/admin/edit_visitor/{id}', 'AdminsController@editVisitor');

Route::get('/admin/certificate/{id}', 'AdminsController@certificate');

Route::get('/admin/visitors_subscriptions', 'AdminsController@visitorsSubscriptions');
Route::get('/admin/members_subscriptions', 'AdminsController@membersSubscriptions');

Route::get('/test', 'CustomersController@test');
Route::get('/test/sms/{phone}', 'UsersController@sendSms');