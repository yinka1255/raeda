<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use Session;
use Redirect;
use App\User;
use App\Visitor;
use App\Member;
use App\Comment;
use App\VisitorSubscription;
use App\Course;
use App\Appointment;
use App\CourseQuestion;
use App\Exam;
use App\Plan;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Mail;
use Carbon\Carbon;

class VisitorsController extends Controller{

    public function courses($course_id){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        if($course_id == 4){
            $prospect = Visitor::where("id", $loggedInUser->id)->first();
            $prospect->stage = 5;
            $prospect->save();
        }  
        if($course_id == 5){
            $prospect = Visitor::where("id", $loggedInUser->id)->first();
            $prospect->stage = 6;
            $prospect->save();
        }    
        
        $course = Course::where("id", $course_id)->first();
        $course_questions = CourseQuestion::where(["course_id"=>$course_id, "status"=>1])->get();
        $passed = Exam::where(["visitor_id"=>$loggedInUser->id,"course_id"=>$course_id])->where("score", ">=", "60")->first();
        $sat = Exam::where(["visitor_id"=>$loggedInUser->id, "course_id"=>$course_id])->where("score", "<", "60")->get();
        return view('visitors/courses')->with(["loggedInUser"=>$loggedInUser, "course"=>$course, "course_questions"=>$course_questions, "passed"=>$passed, "sat"=>$sat]);
    } 

    public function video($member_id){
        $team = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.id", $member_id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $comments = Comment::join("members", "members.id", "=", "comments.member_id")
        ->join("visitors", "visitors.id", "=", "comments.visitor_id")
        ->select("comments.*", "members.first_name as member_first_name", "members.last_name as member_last_name", "members.team_id as member_team_id", "visitors.first_name as visitor_first_name", "visitors.last_name as visitor_last_name")
        ->orderBy("id", "desc")
        ->where("comments.member_id", $member_id)->get();
        $subscriptions = MemberSubscription::where("member_id", $member_id)->orderBy("id", "DESC")->get();
        return view('visitors/video')->with(["team"=>$team, "comments"=>$comments,  "subscriptions"=>$subscriptions]);
    } 
    
    public function forgotPassword($id_number){
        
        return view('visitors/forgot-password')->with(["id_number"=>$id_number]);
    } 
    
    public function certificate(){
       $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/visitors/login');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        return view('visitors/certificate')->with(["loggedInUser"=>$loggedInUser, "date"=> date('Y-m-d')]);
    } 

    public function ods(){
        return response()->download(public_path().'/main/docs/gpt.ods');
    }
    public function answer(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/visitors/login');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $all_fields = $request->all();
        //print_r($all_fields[2]);
        $field_length = count($all_fields) - 2;
        $score = 0;
        $g = [];
        $u = [];
        for($i = 0; $i < $field_length; $i++){
            $cq_id_arr = explode("_", $all_fields[$i], 2);
            $cq_id = $cq_id_arr[0];
            $cq_value = substr($all_fields[$i], strpos($all_fields[$i], "_") + 1); 
            
            $answer = CourseQuestion::where("id", $cq_id)->select('answer')->first();
            if($cq_value == $answer->answer){
                $score += 1;
            }
                
        }
        
        $exam = new Exam;
        $exam->course_id = $request->input('course_id');
        $exam->visitor_id = $loggedInUser->id;
        $exam->score = ($score/$field_length)*100;
        $exam->status = 1;
        if($exam->save()){
            if($request->input('course_id') == 1){
                $prospect = Visitor::where("id", $loggedInUser->id)->first();
                $prospect->stage = 2;
                $prospect->save();
            }
            if($request->input('course_id') == 2){
                $prospect = Visitor::where("id", $loggedInUser->id)->first();
                $prospect->stage = 3;
                $prospect->save();
            }
            if($request->input('course_id') == 3){
                $prospect = Visitor::where("id", $loggedInUser->id)->first();
                $prospect->stage = 4;
                $prospect->save();
            }
            

            Session::flash('success', 'Exam has been saved');
            return back();
        }
        
    }

    public function subscribe(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/visitors/login');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $subscription = new VisitorSubscription;
        $subscription->visitor_id = $loggedInUser->id;
        $subscription->amount = $request->input('amount');
        $subscription->plan_id = $request->input('plan_id');
        $subscription->status = 1;
        $subscription->transaction_ref = $request->input('transaction_ref');
        if($subscription->save()){
            $prospect = Visitor::where("id", $loggedInUser->id)->first();
                $prospect->stage = 7;
                $prospect->save();
            Session::flash('sub_success', 'Your subscription was successfull');
            return back();
        }else{
            Session::flash('sub_error', 'An error occured');
            return back();
        }

    }

    public function profile(){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $subscription = VisitorSubscription::where(["visitor_id"=>$loggedInUser->id])->first();
        $plans = Plan::where("status", 1)->get();
        return view('visitors/profile')->with(["loggedInUser"=>$loggedInUser, "subscription"=>$subscription, "plans"=>$plans]);
    } 
    

    public function appointments(){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $appointments = Appointment::join("members", "members.id", "=", "appointments.member_id")
        ->select("appointments.*", "members.first_name as member_first_name", "members.last_name as member_last_name", "members.team_id as member_team_id")
        ->orderBy("id", "desc")
        ->where("appointments.visitor_id", $loggedInUser->id)->get();
        return view('visitors/appointments')->with(["loggedInUser"=>$loggedInUser, "appointments"=>$appointments]);
    } 
    public function newAppointment(){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        
        return view('visitors/new_appointment')->with(["loggedInUser"=>$loggedInUser]);
    } 

    public function createAppointment(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/visitors/login');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $appointment = new Appointment;
        $appointment->member_id = $loggedInUser->member_id;
        $appointment->visitor_id = $loggedInUser->id;
        $appointment->title = $request->input('title');
        $appointment->start_date = $request->input('start_date') ." ".$request->input('start_time');
        $appointment->status = 1;
        if($appointment->save()){
            $member = Member::where("id", $loggedInUser->member_id)->first();
            $this->appointmentMail($member);
            Session::flash('success', 'Your appointment was successfull');
            return back();
        }else{
            Session::flash('error', 'An error occured');
            return back();
        }
    }
    public function comments(){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $comments = Comment::join("members", "members.id", "=", "comments.member_id")
        ->join("visitors", "visitors.id", "=", "comments.visitor_id")
        ->select("comments.*", "members.first_name as member_first_name", "members.last_name as member_last_name", "members.team_id as member_team_id", "visitors.first_name as visitor_first_name", "visitors.last_name as visitor_last_name")
        ->orderBy("id", "desc")
        ->where("comments.visitor_id", $loggedInUser->id)->get();
        return view('visitors/comments')->with(["loggedInUser"=>$loggedInUser, "comments"=>$comments]);
    } 
    public function newComment(){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        
        return view('visitors/new_comment')->with(["loggedInUser"=>$loggedInUser]);
    } 

    public function createComment(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/visitors/login');
        }
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $comment = new Comment;
        $comment->member_id = $loggedInUser->member_id;
        $comment->visitor_id = $loggedInUser->id;
        $comment->message = $request->input('message');
        $comment->status = 1;
        if($comment->save()){
            Session::flash('success', 'Your comment was successfull');
            return redirect('visitors/comments');
        }else{
            Session::flash('error', 'An error occured');
            return back();
        }

    }

    public function updateProfile(Request $request){
    
        $user = Auth::user();
        if($user == null || $user->type != 3){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/visitors/login');
        }
        $visitor = Visitor::where("visitors.user_id", $user->id)->first();
        $visitor->name = $request->input("name");
        $visitor->first_name = $request->input("first_name");
        $visitor->last_name = $request->input("last_name");
        $visitor->partner_name = $request->input("partner_name");
        $visitor->phone = $request->input("phone");
        $visitor->partner_phone = $request->input("partner_phone");
        $visitor->dob = $request->input("dob");
        $visitor->address = $request->input("address");
        $visitor->email = $request->input("email");
        $visitor->bank = $request->input("bank");
        $visitor->bank_account_name = $request->input("bank_account_name");
        $visitor->bank_account_number = $request->input("bank_account_number");
        $visitor->bank_account_type = $request->input("bank_account_type");
        $visitor->branch_code = $request->input("branch_code");
        $visitor->branch_name = $request->input("branch_name");
        $user = User::where("id", $user->id)->first();
        $user->email = $request->input("email");
        if($visitor->save()){
            $user->save();
            Session::flash('success', "Profile updated succeessfully");
            return back();
        }else{
            Session::flash('error', 'An error occured while trying to update profile.');
            return back();
        }    
    }  
    
    
    public function appointmentMail($member){
        $data = [
        'email'=> $member->email,
        'name'=> $member->first_name,
        ];
 
        Mail::send('member-mail-for-appointment', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->subject('New appointment notification');
            //return response()->json(["succeess"=>'An Email has been sent to your account. Pls check to proceed']);
        });   
    }

    public function updatePassword(Request $request){

        if($request->input("password") != $request->input("cpassword")){
            Session::flash('error', 'Sorry!, The two passwords provided must match');
            return back();
        }
        $user = Auth::user();
        
        $user = User::where("id", $user->id)->first();

        $user->password = bcrypt($request->input("password"));

        $user->save();

        Session::flash('success', 'Thank you, your password has been updated successfully');
        return back();
    }

    
}
