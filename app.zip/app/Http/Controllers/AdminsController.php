<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use Session;
use Redirect;
use App\User;
use App\Member;
use App\MemberSubscription;
use App\Visitor;
use App\Plan;
use App\VisitorSubscription;
use App\Admin;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Mail;
use Carbon\Carbon;

class AdminsController extends Controller{
public function index(){
    
        $user = Auth::user();
        if($user == null || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('admin/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        $members_count = Member::count();
        $visitors_count = Visitor::count();
        $members_subscriptions_this_year_count = MemberSubscription::whereYear('created_at', Carbon::now()->year)->count();
        $visitors_subscriptions_this_year_count = VisitorSubscription::whereYear('created_at', Carbon::now()->year)->count();
        return view('admin/index')->with(["loggedInUser"=>$loggedInUser, "members_count"=>$members_count, "visitors_count"=>$visitors_count, "visitors_subscriptions_this_year_count"=>$visitors_subscriptions_this_year_count, "members_subscriptions_this_year_count"=>$members_subscriptions_this_year_count]);
    }
    
    public function admins(){
    
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();

        $admins = Admin::join("users", "admins.user_id", "=", "users.id")
                    ->orderBy("users.id", "desc")
                    ->select("admins.*", "users.id as user_id", "users.status as user_status")->get();

        return view('admin/admins')->with(["admins"=>$admins, "loggedInUser"=>$loggedInUser]);
    } 
    
    public function profile(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();

        return view('admin/profile')->with(["loggedInUser"=>$loggedInUser]);
    } 

    public function newAdmin(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        return view('admin/new_admin')->with(["loggedInUser"=>$loggedInUser]);
    }
    
    public function newMember(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        return view('admin/new_member')->with(["loggedInUser"=>$loggedInUser]);
    }
    
    public function regMember($id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        $member = Member::where("id", $id)->first();
        $member->status = 1;
        $member->save();
        return back();
    }
    
    public function editAdmin($id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        $admin = Admin::where("id", $id)->first();
        return view('admin/edit_admin')->with(["admin"=>$admin, "loggedInUser"=>$loggedInUser]);
    }
    
    public function editVisitor($id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
       $visitor = Visitor::where("visitors.id", $id)
                    ->join("users", "visitors.user_id", "=", "users.id")
                    ->join("members", "visitors.member_id", "=", "members.id")
                ->select("visitors.*", "members.team_id", "members.id_number", "members.first_name as member_first_name", "members.last_name as member_last_name", "users.id as user_id", "users.status as user_status")->first();
                
        $subscriptions = VisitorSubscription::where("visitor_id", $id)->orderBy("id", "DESC")->get();
        return view('admin/visitor_details')->with(["visitor"=>$visitor, "subscriptions"=>$subscriptions, "loggedInUser"=>$loggedInUser]);
    }
    public function certificate($id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
       $visitor = Visitor::where("visitors.id", $id)
                    ->join("users", "visitors.user_id", "=", "users.id")
                    ->join("members", "visitors.member_id", "=", "members.id")
                ->select("visitors.*", "members.team_id", "users.id as user_id", "users.status as user_status")->first();
                
        return view('admin/certificate')->with(["visitor"=>$visitor, "date"=> date('Y-m-d'), "loggedInUser"=>$loggedInUser]);
    }
    
    public function visitorsSubscriptions(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
              
        $subscriptions = VisitorSubscription::join("visitors", "visitors.id", "=", "visitor_subscriptions.visitor_id")
                        ->select("visitor_subscriptions.*", "visitors.first_name", "visitors.last_name", "visitors.id as visitor_id")
                        ->orderBy("visitor_subscriptions.id", "DESC")->get();
        return view('admin/visitors_subscriptions')->with([ "subscriptions"=>$subscriptions, "loggedInUser"=>$loggedInUser]);
    }
    
    public function membersSubscriptions(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
              
        $subscriptions = MemberSubscription::join("members", "members.id", "=", "member_subscriptions.member_id")
                        ->select("member_subscriptions.*", "members.first_name", "members.last_name", "members.id as member_id")
                        ->orderBy("member_subscriptions.id", "DESC")->get();
        return view('admin/members_subscriptions')->with([ "subscriptions"=>$subscriptions, "loggedInUser"=>$loggedInUser]);
    }
    
    public function editMember($id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
       $member = Member::where("members.id", $id)
           ->join("users", "members.user_id", "=", "users.id")
                ->select("members.*", "users.id as user_id", "users.status as user_status")->first();
                
        $subscriptions = MemberSubscription::where("member_id", $id)->orderBy("id", "DESC")->get();
        $plans = Plan::where("status", 1)->get();
        return view('admin/member_details')->with(["member"=>$member, "subscriptions"=>$subscriptions, "plans"=>$plans, "loggedInUser"=>$loggedInUser]);
    }
    
    public function visitors(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        
        $visitors = Visitor::join("users", "visitors.user_id", "=", "users.id")
                    ->join("members", "visitors.member_id", "=", "members.id")
                ->select("visitors.*", "members.team_id", "users.id as user_id", "users.status as user_status")->get();

        return view('admin/visitors')->with(["visitors"=>$visitors, "loggedInUser"=>$loggedInUser]);
    }  
    
    public function members(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        
        $members = Member::join("users", "members.user_id", "=", "users.id")
                ->select("members.*", "members.team_id", "users.id as user_id", "users.status as user_status")->get();

        return view('admin/members')->with(["members"=>$members, "loggedInUser"=>$loggedInUser]);
    }  
    
    public function plans(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        $plans = Plan::all();

        return view('admin/plans')->with(["plans"=>$plans, "loggedInUser"=>$loggedInUser]);
    }  
    
    public function newPlan(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
                
        return view('admin/new_plan')->with(["loggedInUser"=>$loggedInUser]);
    }
    
    
    public function editPlan($id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
       $plan = Plan::where("id", $id)->first();
                
        return view('admin/edit_plan')->with(["plan"=>$plan, "loggedInUser"=>$loggedInUser]);
    }
    
     public function savePlan(Request $request){
        
        $plan = new Plan;
        $plan->name = $request->input("name");
        $plan->amount = $request->input('amount');
        $plan->days = $request->input("days");
        $plan->status = 1;
        if($plan->save()){
            Session::flash('success', 'Plan created successfully');
            return redirect("admin/plans");
        }else{
            Session::flash('error', 'Sorry! an unknown error occured');
            return back();
        }
            
    }
    
    public function addSubscription(Request $request){
        
        $plan = Plan::where("id", $request->input('plan_id'))->first();
        $subscription = new MemberSubscription;
        $subscription->member_id = $request->input('member_id');
        $subscription->amount = $plan->amount;
       
        $subscription->plan = $plan->name;
        $subscription->expiry_date = date('Y-m-d',strtotime(+$plan->days.' days',strtotime(now())));
        $subscription->status = 1;
        $subscription->transaction_ref = time();
        if($subscription->save()){
            Session::flash('success', 'Subscription added successfully');
            return back();
        }else{
            Session::flash('error', 'Sorry! an unknown error occured');
            return back();
        }
    }
    
    public function sendCertificate(Request $request){
        
        
        $data = [
        'email'=> $request->input('email'),
        'name'=> $request->input('name'),
        'date'=>date('Y-m-d')
        ];
 
        Mail::send('certificate-mail', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->attach($request->input('certificate'));
            $message->subject('Certificate');
            
        });   
        
        Session::flash('success', 'Certificate sent successfully');
        return back();
        
            
    }
    public function updatePlan(Request $request){
        
        $plan = Plan::where("id", $request->input('id'))->first();
        $plan->name = $request->input("name");
        $plan->amount = $request->input('amount');
        $plan->days = $request->input("days");
        $plan->status = 1;
        if($plan->save()){
            Session::flash('success', 'Plan updated successfully');
            return redirect("admin/plans");
        }else{
            Session::flash('error', 'Sorry! an unknown error occured');
            return back();
        }
            
    }
    
    public function saveMember(Request $request){
        $check = User::where("email", $request->input("email"))->first();
        if($check != null){
            Session::flash('error', 'Sorry! Email already exist');
            return back();
        }  
        if(substr($request->input("team_id"), 0, 3) != "63-"){
            Session::flash('error', 'Sorry! the provided team ID is not in the correct format');
            return back();
        }
        if(strlen($request->input("team_id")) != "10"){
            Session::flash('error', 'Sorry! the provided team ID is not in the correct format');
            return back();
        }
        if(substr($request->input("id_number"), 0, 3) != "63-"){
            Session::flash('error', 'Sorry! the provided ID number is not in the correct format');
            return back();
        }
        if(strlen($request->input("id_number")) != "10"){
            Session::flash('error', 'Sorry! the provided ID number is not in the correct format');
            return back();
        }
        
        $checkIdNumber = User::where("id_number", $request->input("id_number"))->count();
        if($checkIdNumber > 0){
            Session::flash('error', 'Sorry! the provided ID number already exist. Kindly login');
            return back();
        }
        $user = new User;
        $user->email = $request->input("email");
        $password = $request->input("password");
        $user->password = bcrypt($password);
        $user->team_id = $request->input("team_id");
        $user->id_number = $request->input("id_number");
        $user->type = 2;
        $user->status = 1;
        if($user->save()){
            $member = new Member;
            $member->user_id = $user->id;
            $member->first_name = $request->input("first_name");
            $member->last_name = $request->input("last_name");
            $member->phone = $request->input("phone");
            $member->email = $request->input("email");
            $member->team_id = $request->input("team_id");
            $member->id_number = $request->input("id_number");
            
            if($member->save()){
                
                $subscription = new MemberSubscription;
                $subscription->member_id = $member->id;
                $subscription->amount = 10000000;
                //$subscription->plan = $request->input('plan');
               
                    $subscription->plan = "Admin manual subscription";
                    $subscription->expiry_date = date('Y-m-d',strtotime('+300000 days',strtotime(now())));
                    $subscription->status = 1;
                    $subscription->transaction_ref = time();
                    $subscription->save();
                //$this->adminMail($request->input("email"), $request->input("name"), $password);
                Session::flash('success', 'Thank you, member account has been created successfully');
                return redirect('/admin/members');
            }else{
                Session::flash('error', 'Sorry! An error occured while trying to create account');
                return back();
            }    
        }else{
            Session::flash('error', 'Sorry! An error occured while trying to create account');
                return back();
        }    
    }  
    
    public function unregisteredMembers(){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        
        $members = Member::join("users", "members.user_id", "=", "users.id")
                            ->where("members.status", null)
                ->select("members.*", "members.team_id", "users.id as user_id", "users.status as user_status")->get();

        return view('admin/unregistered_members')->with(["members"=>$members, "loggedInUser"=>$loggedInUser]);
    }  

    public function customerDetails($customer_id){
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Admin::join("users", "admins.user_id", "=", "users.id")
                        ->where("admins.user_id", $user->id)
                        ->select("admins.*", "users.id as user_id", "users.status as user_status")->first();
        
        $customer = Customer::join("users", "customers.user_id", "=", "users.id")
                                ->where("customers.id", $customer_id)
                                ->select("customers.*", "users.id as user_id", "users.status as user_status")->first();
        $vendor = Vendor::where("id", $customer->vendor_id)->first();
        $customer['vendor'] = $vendor;
        $transactions = Transaction::
            where(function ($q) use ($customer) {
                $q->where('type', 1);
                $q->where("customer_id",$customer->id);
            })
            ->orWhere(function ($q) use ($customer) {
                $q->where('type', 2);
                $q->where("customer_id",$customer->id);
            })
            ->orWhere(function ($q) use ($customer) {
                $q->where('type', 3);
                $q->where("customer_id",$customer->id);
            })
            ->orWhere(function ($q) use ($customer) {
                $q->where('type', 4);
                $q->where("customer_id",$customer->id);
            })
            ->orWhere(function ($q) use ($customer) {
                $q->where('type',4);
                $q->where("bill_customer_id",$customer->id);
            })
            ->orWhere(function ($q) use ($customer) {
                $q->where('type', 5);
                $q->where("customer_id",$customer->id);
            })
            ->orWhere(function ($q) use ($customer) {
                $q->where('type',5);
                $q->where("bill_customer_id",$customer->id);
            })
            
        ->get();
        return view('admin/customer_details')->with(["customer"=>$customer, "loggedInUser"=>$loggedInUser, "transactions"=>$transactions]);
    }  

    public function admin($id){
    
        $admin = Admin::where("id", $id)->first();

        return response()->json(['error' => false, 'admin' => $admin], 200);
    }  

    public function deactivateAdmin($id){
    
        $user = User::where("id", $id)->first();

        $user->status = 2;

        $user->save();

        Session::flash('success', 'Thank you, User has been deactivated successfully');
        return back();
    }  
    public function activateAdmin($id){
    
        $user = User::where("id", $id)->first();

        $user->status = 1;

        $user->save();

        Session::flash('success', 'Thank you, User has been activated successfully');
        return back();
    }  
    
    public function deactivatePlan($id){
    
        $plan = Plan::where("id", $id)->first();

        $plan->status = 2;

        $plan->save();

        Session::flash('success', 'Thank you, Plan has been deactivated successfully');
        return back();
    }  
    public function activatePlan($id){
    
        $plan = Plan::where("id", $id)->first();

        $plan->status = 1;

        $plan->save();

        Session::flash('success', 'Thank you, Plan has been activated successfully');
        return back();
    }  

    

    public function sendWelcomeMail($member){
        $data = [
        'email'=> $member->email,
        'name'=> $member->name,
        ];
 
        Mail::send('member-mail-for-visitor-reg', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->subject('New prospect notification');
            //return response()->json(["succeess"=>'An Email has been sent to your account. Pls check to proceed']);
        });   
    }

    public function forgotPasswordPost(Request $request){

        if(empty($request->input("email"))){
            Session::flash('error', 'Kindly provide your email address');
            return back();
        }
        $user = User::where("email", $request->input("email"))->first();
        if($user == null){
            Session::flash('error', 'No user associated with the provided email');
            return back();
        }
        $token = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 4)), 0, 4);
        $user->password = bcrypt($token);
        $user->save();
        if($user->type == 3){
            $visitor = Visitor::where("visitor_id", $user->id)->first();
            $this->sendResetMail($visitor, $token);
        }elseif($user->type == 2){
            $member = Member::where("id", $user->id)->first();
            $this->sendResetMail($member, $token);
        }elseif($user->type == 1){
            $admin = Admin::where("id", $user->id)->first();
            $this->sendResetMail($admin, $token);
        }
        Session::flash('success', 'An Email has been sent to your account. Pls check to proceed');
        return back();
    }
    
    public function saveAdmin(Request $request){
        $check = User::where("email", $request->input("email"))->first();
        if($check != null){
            Session::flash('error', 'Sorry! Email already exist');
            return back();
        }  
        $user = new User;
        $user->email = $request->input("email");
        $password = time();
        $user->password = bcrypt($password);
        $user->type = 1;
        $user->status = 1;
        if($user->save()){
            $admin = new Admin;
            $admin->user_id = $user->id;
            $admin->name = $request->input("name");
            $admin->phone = $request->input("phone");
            $admin->email = $request->input("email");
            
            if($admin->save()){
                //$this->adminMail($request->input("email"), $request->input("name"), $password);
                Session::flash('success', 'Thank you, admin account has been created successfully');
                return redirect('/admin/admins');
            }else{
                Session::flash('error', 'Sorry! An error occured while trying to create account');
                return back();
            }    
        }else{
            Session::flash('error', 'Sorry! An error occured while trying to create account');
                return back();
        }    
    }  

    public function updateAdmin(Request $request){
    
        $admin = Admin::where("user_id", $request->input("user_id"))->first();
        $admin->name = $request->input("name");
        //$admin->phone = $request->input("phone");
        //$admin->address = $request->input("address");
        $admin->email = $request->input("email");
        $user = User::where("id", $request->input("user_id"))->first();
        $user->email = $request->input("email");
        if($admin->save()){
            $user->save();
            return response()->json(['success' => true, 'message' => "Profile updated succeessfully"], 200);
        }else{
            return response()->json(['error' => true, 'message' => "An error occured while trying to update profile."], 200);
        }    
    }  

    public function updateProfile(Request $request){
    
        $user = Auth::user();
        if(!$user || $user->type != 1){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $admin = Admin::where("admins.user_id", $user->id)->first();
        $admin->name = $request->input("name");
        $admin->phone = $request->input("phone");
        $admin->email = $request->input("email");
        $user = User::where("id", $user->id)->first();
        $user->email = $request->input("email");
        if($admin->save()){
            $user->save();
            Session::flash('success', "Profile updated succeessfully");
            return back();
        }else{
            Session::flash('error', 'An error occured while trying to update profile.');
            return back();
        }    
    }  

    public function updatePassword(Request $request){

        if($request->input("password") != $request->input("password1")){
            Session::flash('error', 'Sorry!, The two passwords provided must match');
            return back();
        }
        $user = Auth::user();
        
        $user = User::where("id", $user->id)->first();

        $user->password = bcrypt($request->input("password"));

        $user->save();

        Session::flash('success', 'Thank you, your password has been updated successfully');
        return back();
    }

    public function updateAdminPassword(Request $request){

        if($request->input("password") != $request->input("cpassword")){
            Session::flash('error', 'Sorry!, The two passwords provided must matchy');
            return back();
        }
        $user = Auth::user();
        
        //$user = User::where("username", $user->username)->first();

        $user->password = bcrypt($request->input("password"));

        $user->save();

        Session::flash('success', 'Thank you, your password has been updated successfully');
        return back();
    }

    public function sendResetMail($member, $token){
        $data = [
        'email'=> $member->email,
        'name'=> $member->first_name,
        'token'=> $token,
        'date'=>date('Y-m-d')
        ];
 
        Mail::send('reset-mail', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->subject('Password Recovery');
            
        });   
    }
}
