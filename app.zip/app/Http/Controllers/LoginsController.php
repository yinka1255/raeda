<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Session;
use App\Customer;
use App\Member;
use App\Visitor;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;

class LoginsController extends Controller
{

    /**
	 * Handles authentication attempt
	 *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */
    public function authenticate(Request $request){
    	$id_number = $request->input('id_number');
        $password = $request->input('password');
    	if (Auth::attempt(['id_number' => $id_number, 'password' => $password])){
            $user = Auth::user();
            if($user->status == 2){
                Session::flash('error', 'Sorry! Your account has been deactivated');
                return back();
            }  
            if($user->type == 3){
                Session::flash('success', 'Authentication was successfull');
                return redirect('visitors/courses/1');
            }    
            if($user->type == 2){
                Session::flash('success', 'Authentication was successfull');
                return redirect('members/profile');
            }   
            if($user->type == 1){
                Session::flash('success', 'Authentication was successfull');
                return redirect('admin/index');
            }   
           
        }else{		
                Session::flash('error', 'Authentication failed. Kindly try again with valid details');
                return back();
        }

    }
    public function visitorsAuthenticate(Request $request){
    	$email = $request->input('email');
        $password = $request->input('password');
    	if (Auth::attempt(['email' => $email, 'password' => $password])){
            $user = Auth::user();
            if($user->status == 2){
                Session::flash('error', 'Sorry! Your account has been deactivated');
                return back();
            }  
            if($user->type == 3){
                $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
                if($loggedInUser->stage == null || $loggedInUser->stage == 1){
                    Session::flash('success', 'Authentication was successfull');
                    return redirect('visitors/courses/1');
                }elseif($loggedInUser->stage == 2){
                    Session::flash('success', 'Authentication was successfull');
                    return redirect('visitors/courses/2');
                }
                elseif($loggedInUser->stage == 3){
                    Session::flash('success', 'Authentication was successfull');
                    return redirect('visitors/courses/3');
                }
                elseif($loggedInUser->stage == 4){
                    Session::flash('success', 'Authentication was successfull');
                    return redirect('visitors/courses/4');
                }
                elseif($loggedInUser->stage == 5){
                    Session::flash('success', 'Authentication was successfull');
                    return redirect('visitors/courses/5');
                }
                elseif($loggedInUser->stage > 5){
                    Session::flash('success', 'Authentication was successfull');
                    return redirect('visitors/profile');
                }
            }    
            if($user->type == 2){
                Session::flash('success', 'Authentication was successfull');
                return redirect('members/profile');
            }   
            if($user->type == 1){
                Session::flash('success', 'Authentication was successfull');
                return redirect('admin/index');
            }   
           
        }else{		
                Session::flash('error', 'Authentication failed. Kindly try again with valid details');
                return back();
        }

    }

    public function mobileLogin(Request $request){
    	$email = $request->input('email');
        $password = $request->input('password');
    	if (Auth::attempt(['email' => $email, 'password' => $password])){
            $user = Auth::user();
            
            if($user->status == 2){
                return response()->json(['error' => 'Sorry! Your account has been deactivated. Kindly contact administrator']);
            }   
            if($user->type == 3){
                $customer = Customer::where("user_id", $user->id)->first();
                return response()->json(['success' => 'Authentication was successfull', 'customer'=>$customer]);
            }    
        }else{		
            return response()->json(['error' => 'Sorry! Authentication failed... Kindly try again']);
        }

    }

    public function membersLogout(){
        
        Auth::logout();
        return redirect('/');
    }

    public function logout(){
        /*
        $user = Auth::user();
        $loggedInUser = Visitor::join("users", "visitors.user_id", "=", "users.id")
                        ->where("visitors.user_id", $user->id)
                        ->select("visitors.*", "users.id as user_id", "users.status as user_status")->first();
        $team = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.id", $loggedInUser->member_id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        
        */
        Auth::logout();
        return redirect('/');
    }

    public function adminLogout(){
        
        $user = Auth::user();
        Auth::logout();
        return redirect('admin/');
    }
}
