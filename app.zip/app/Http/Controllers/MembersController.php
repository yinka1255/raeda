<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use Session;
use Redirect;
use App\User;
use App\Member;
use App\Comment;
use App\Visitor;
use App\Appointment;
use App\Plan;
use App\Broadcast;
use App\Note;
use App\VisitorSubscription;
use App\MemberSubscription;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Mail;
use Carbon\Carbon;

class MembersController extends Controller{


    public function profile(){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $subscription = MemberSubscription::where(["member_id"=>$loggedInUser->id])->orderBy("id", "DESC")->first();
        $active_subscription = MemberSubscription::where(["member_id"=>$loggedInUser->id,])->where("expiry_date", ">", now() )->first();
        $plans = Plan::where("status", 1)->get();
        return view('members/profile')->with(["loggedInUser"=>$loggedInUser, "subscription"=>$subscription, "active_subscription"=>$active_subscription, "plans"=>$plans]);
    } 

    public function visitors(){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $visitors = Visitor::where("member_id", $loggedInUser->id)->get();
        return view('members/visitors')->with(["loggedInUser"=>$loggedInUser, "visitors"=>$visitors]);
    } 
    public function visitorDetails($id){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $visitor = Visitor::where("visitors.id", $id)
                    ->join("users", "visitors.user_id", "=", "users.id")
                    ->join("members", "visitors.member_id", "=", "members.id")
                ->select("visitors.*", "members.team_id", "members.id_number", "members.first_name as member_first_name", "members.last_name as member_last_name", "users.id as user_id", "users.status as user_status")->first();
                
        $subscriptions = VisitorSubscription::where("visitor_id", $id)->orderBy("id", "DESC")->get();
        $notes = Note::where("visitor_id", $id)->orderBy("id", "DESC")->get();
        
        return view('members/visitor_details')->with(["loggedInUser"=>$loggedInUser,  "subscriptions"=>$subscriptions, "notes"=>$notes, "visitor"=>$visitor]);
    } 
    public function appointments(){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $appointments = Appointment::join("visitors", "visitors.id", "=", "appointments.visitor_id")
        ->select("appointments.*", "visitors.first_name as visitor_first_name", "visitors.last_name as visitor_last_name", "visitors.email as visitor_email", "visitors.phone as visitor_phone")
        ->orderBy("id", "desc")
        ->where("appointments.member_id", $loggedInUser->id)->get();
        return view('members/appointments')->with(["loggedInUser"=>$loggedInUser, "appointments"=>$appointments]);
    } 

    public function broadcasts(){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $broadcasts = Broadcast::leftjoin("visitors", "visitors.id", "=", "broadcasts.visitor_id")
                        ->select("broadcasts.*", "visitors.name as visitor_name", "visitors.email as visitor_email", "visitors.phone as visitor_phone")
                        ->orderBy("id", "desc")
                        ->where("broadcasts.member_id", $loggedInUser->id)->get();
        $visitors = Visitor::where("member_id", $loggedInUser->id)->get();
        return view('members/broadcasts')->with(["loggedInUser"=>$loggedInUser, "broadcasts"=>$broadcasts, "visitors"=>$visitors]);
    } 

    public function newBroadcast(){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id")->first();
        
        $visitors = Visitor::where("member_id", $loggedInUser->id)->get();
        return view('members/new_broadcast')->with(["loggedInUser"=>$loggedInUser, "visitors"=>$visitors]);
    } 

    public function createBroadcast(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id")->first();
        $broadcast = new Broadcast;
        $broadcast->member_id = $loggedInUser->id;
        $broadcast->visitor_id = $request->input('visitor_id');
        $broadcast->title = $request->input('title');
        $broadcast->message = $request->input('message');
        $broadcast->status = 1;
        if($broadcast->save()){
            Session::flash('success', 'Your broadcast was successfull');
            return back();
        }else{
            Session::flash('error', 'An error occured');
            return back();
        }

    }
    
    public function addNote(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id")->first();
        $note = new Note;
        $note->member_id = $loggedInUser->id;
        $note->visitor_id = $request->input('visitor_id');
        $note->body = $request->input('body');
        if($note->save()){
            Session::flash('success', 'Your note was successfull');
            return back();
        }else{
            Session::flash('error', 'An error occured');
            return back();
        }

    }

    public function video($id_number){
        $team = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("users.id_number", $id_number)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $comments = Comment::join("members", "members.id", "=", "comments.member_id")
                        ->join("visitors", "visitors.id", "=", "comments.visitor_id")
                        ->select("comments.*", "members.first_name as member_first_name", "members.last_name as member_last_name", "members.team_id as member_team_id", "visitors.first_name as visitor_first_name", "visitors.last_name as visitor_last_name")
                        ->orderBy("id", "desc")
                        ->where("comments.member_id", $team->id)->get();
        $subscriptions = MemberSubscription::where("member_id", $team->id)->orderBy("id", "DESC")->get();
        return view('visitors/video')->with(["team"=>$team, "comments"=>$comments,  "subscriptions"=>$subscriptions]);
    } 

    public function subscribe(Request $request){
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $loggedInUser = Member::join("users", "members.user_id", "=", "users.id")
                        ->where("members.user_id", $user->id)
                        ->select("members.*", "users.id as user_id", "users.status as user_status", "users.team_id as team_id", "users.id_number as id_number")->first();
        $plan = Plan::where("id", $request->input("plan_id"))->first();
        $subscription = new MemberSubscription;
        $subscription->member_id = $loggedInUser->id;
        $subscription->amount = $request->input('amount');
        //$subscription->plan = $request->input('plan');
        //if($request->input('amount') == "2000"){
            $subscription->plan = $plan->name;
            $subscription->plan_id = $plan->id;
            $subscription->expiry_date = date('Y-m-d',strtotime("+$plan->days days",strtotime(now())));
            
            /*
        }elseif($request->input('amount') == "1500"){
            $subscription->plan = "Subsequent subscription";
            $subscription->expiry_date = date('Y-m-d',strtotime('+30 days',strtotime(now())));
        }
        elseif($request->input('amount') == "3900"){
            $subscription->plan = "Subsequent subscription";
            $subscription->expiry_date = date('Y-m-d',strtotime('+90 days',strtotime(now())));
        }
        elseif($request->input('amount') == "6600"){
            $subscription->plan = "Subsequent subscription";
            $subscription->expiry_date = date('Y-m-d',strtotime('+180 days',strtotime(now())));
        }elseif($request->input('amount') == "9000"){
            $subscription->plan = "Subsequent subscription";
            $subscription->expiry_date = date('Y-m-d',strtotime('+360 days',strtotime(now())));
        }
        */
        $subscription->status = 1;
        $subscription->transaction_ref = $request->input('transaction_ref');
        if($subscription->save()){
            Session::flash('sub_success', 'Your subscription was successfull');
            return back();
        }else{
            Session::flash('sub_error', 'An error occured');
            return back();
        }

    }

    public function updateProfile(Request $request){
    
        $user = Auth::user();
        if($user == null || $user->type != 2){
            Session::flash('error', 'Sorry! You do not have access to this page');
            return redirect('/login');
        }
        $member = Member::where("members.user_id", $user->id)->first();
        $member->name = $request->input("name");
        $member->first_name = $request->input("first_name");
        $member->last_name = $request->input("last_name");
        $member->phone = $request->input("phone");
        $member->dob = $request->input("dob");
        $member->email = $request->input("email");
        $user = User::where("id", $user->id)->first();
        $user->email = $request->input("email");
        if($member->save()){
            $user->save();
            Session::flash('success', "Profile updated succeessfully");
            return back();
        }else{
            Session::flash('error', 'An error occured while trying to update profile.');
            return back();
        }    
    }  

    public function updatePassword(Request $request){

        if($request->input("password") != $request->input("cpassword")){
            Session::flash('error', 'Sorry!, The two passwords provided must match');
            return back();
        }
        $user = Auth::user();
        
        $user = User::where("id", $user->id)->first();

        $user->password = bcrypt($request->input("password"));

        $user->save();

        Session::flash('success', 'Thank you, your password has been updated successfully');
        return back();
    }
}
