<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use Session;
use Redirect;
use App\User;
use App\Member;
use App\Visitor;
use App\Plan;
use App\Admin;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Mail;

class UsersController extends Controller{

    public function index(){
        $plans = Plan::where("status", 1)->get();
        return view('index')->with(["plans"=>$plans]);;
    }
    public function about(){
        return view('about');
    }


    public function terms(){
        return view('terms');
    }

    public function faq(){
        return view('faq');
    }

    public function contact(){
        return view('contact');
    }

    public function register(){
        return view('register');
    }

    public function visitorsRegister($id_number){
        return view('visitors/register')->with("id_number", $id_number);
    }
    public function visitorsLogin($id_number){
        return view('visitors/login')->with("id_number", $id_number);
    }

    public function memberRegister(Request $request){

        
        // if($request->input("password") != $request->input("cpass")){
        //     Session::flash('error', 'Sorry! the provided passwords do not match');
        //     return back();
        // }
        if(substr($request->input("team_id"), 0, 3) != "63-"){
            Session::flash('error', 'Sorry! the provided team ID is not in the correct format');
            return back();
        }
        if(strlen($request->input("team_id")) != "10"){
            Session::flash('error', 'Sorry! the provided team ID is not in the correct format');
            return back();
        }
        if(substr($request->input("id_number"), 0, 3) != "63-"){
            Session::flash('error', 'Sorry! the provided ID number is not in the correct format');
            return back();
        }
        if(strlen($request->input("id_number")) != "10"){
            Session::flash('error', 'Sorry! the provided ID number is not in the correct format');
            return back();
        }
        $check = User::where("email", $request->input("email"))->count();
        if($check > 0){
            Session::flash('error', 'Sorry! the provided email already exist');
            return back();
        }
        /*
        $checkTeamId = User::where("team_id", $request->input("team_id"))->count();
        if($checkTeamId > 0){
            Session::flash('error', 'Sorry! the provided team ID already exist. Kindly login');
            return back();
        }
        */
        $checkIdNumber = User::where("id_number", $request->input("id_number"))->count();
        if($checkIdNumber > 0){
            Session::flash('error', 'Sorry! the provided ID number already exist. Kindly login');
            return back();
        }
        $user = new User;
        $user->email = $request->input("email");
        $user->team_id = $request->input("team_id");
        $user->id_number = $request->input("id_number");
        $user->password = bcrypt($request->input("password"));
        $user->status = 1;
        $user->type = 2;
        if($user->save()){
            $member = new Member;
            $member->user_id = $user->id;
            $member->email = $request->input("email");
            $member->team_id = $request->input("team_id");
            $member->id_number = $request->input("id_number");
            if($member->save()){
                Auth::loginUsingId($user->id);
                //$this->sendWelcomeMail($member);
                
                Session::flash('success', 'Thank you for being a part of Rondo. You are now logged in');
                return redirect('/members/profile');
            }else{
                Session::flash('error', 'Sorry! An error occured while trying to save your information. Kindly contact administrator');
                return back();
            }
        }     
    }

    public function visitorsCreate(Request $request){

        
        // if($request->input("password") != $request->input("cpass")){
        //     Session::flash('error', 'Sorry! the provided passwords do not match');
        //     return back();
        // }
        $check = User::where("email", $request->input("email"))->count();
        if($check > 0){
            Session::flash('error', 'Sorry! the provided email already exist');
            return back();
        }
        $member = Member::where("id_number", $request->input("id_number"))->first();
        if($member === null){
            Session::flash('error', 'Sorry! the member you try to register through does not exist');
            return back();
        }
        $user = new User;
        $user->email = $request->input("email");
        //$user->team_id = $request->input("team_id");
        $user->password = bcrypt($request->input("password"));
        $user->status = 1;
        $user->type = 3;
        if($user->save()){
            $visitor = new Visitor;
            $visitor->user_id = $user->id;
            $visitor->email = $request->input("email");
            $visitor->first_name = $request->input("first_name");
            $visitor->last_name = $request->input("last_name");
            $visitor->phone = $request->input("phone");
            $visitor->address = $request->input("address");
            $visitor->member_id = $member->id;
            if($visitor->save()){
                Auth::loginUsingId($user->id);
                $this->sendWelcomeMail($member);
                $this->sendSMS($member->phone, $visitor);
                
                Session::flash('success', 'Thank you for being a part of Rondo. You are now logged in');
                return redirect('/visitors/courses/1');
            }else{
                Session::flash('error', 'Sorry! An error occured while trying to save your information. Kindly contact administrator');
                return back();
            }
        }     
    }

    public function sendSms($phone, $visitor){
        if($phone != null){
        $quick_buy="https://www.quickbuysms.com/index.php?option=com_spc&comm=spc_api&username=Rondo&password=Rondo&sender=TeamRondo&recipient=".$phone."&message=". urlencode ("Hello, You have a new prospect. Login to your the online portal and attend to your new prospect. Your prospects name is ".$visitor->first_name.", and phone is ".$visitor->phone);

            //star a curl request
            $ch = curl_init($quick_buy);
            //set tor return the request response
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            //
            curl_setopt($ch, CURLOPT_HEADER, 0);
            //the response is saved in the handle
            $handle = curl_exec($ch);
            //Yes, let close the connection, the server Memory will thank us later.
            curl_close($ch);
        }
    }

    public function sendWelcomeMail($member){
        $data = [
        'email'=> $member->email,
        'name'=> $member->first_name,
        ];
 
        Mail::send('member-mail-for-visitor-reg', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->subject('New prospect notification');
            //return response()->json(["succeess"=>'An Email has been sent to your account. Pls check to proceed']);
        });   
    }

    public function forgotPasswordPost(Request $request){

        if(empty($request->input("email"))){
            Session::flash('error', 'Kindly provide your email address');
            return back();
        }
        $user = User::where("email", $request->input("email"))->first();
        if($user == null){
            Session::flash('error', 'No user associated with the provided email');
            return back();
        }
        $token = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 4)), 0, 4);
        $user->password = bcrypt($token);
        $user->save();
        if($user->type == 3){
            $visitor = Visitor::where("user_id", $user->id)->first();
            $this->sendResetMail($visitor, $token);
        }elseif($user->type == 2){
            $member = Member::where("user_id", $user->id)->first();
            $this->sendResetMail($member, $token);
        }elseif($user->type == 1){
            $admin = Admin::where("user_id", $user->id)->first();
            $this->sendResetMail($admin, $token);
        }
        Session::flash('success', 'An Email has been sent to your account. Pls check to proceed');
        return back();
    }
    public function memberForgotPasswordPost(Request $request){

        if(empty($request->input("id_number"))){
            Session::flash('error', 'Kindly provide your ID number');
            return back();
        }
        $user = User::where("id_number", $request->input("id_number"))->first();
        if($user == null){
            Session::flash('error', 'No user associated with the provided id number');
            return back();
        }
        $token = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 4)), 0, 4);
        $user->password = bcrypt($token);
        $user->save();
        
            $member = Member::where("user_id", $user->id)->first();
            $this->sendResetMailMember($member, $token);
        Session::flash('success', 'An Email has been sent to your account. Pls check to proceed');
        return back();
    }

    public function sendResetMail($member, $token){
        $data = [
        'email'=> $member->email,
        'name'=> $member->name,
        'token'=> $token,
        'date'=>date('Y-m-d')
        ];
 
        Mail::send('reset-mail', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->subject('Password Recovery');
            
        });   
    }
    public function sendResetMailMember($member, $token){
        $data = [
        'email'=> $member->email,
        'name'=> $member->first_name,
        'token'=> $token,
        'date'=>date('Y-m-d')
        ];
 
        Mail::send('reset-mail', $data, function($message) use($data){
            $message->from('info@teamrondo.com', 'Team rondo');
            $message->SMTPDebug = 4; 
            $message->to($data['email']);
            $message->subject('Password Recovery');
            
        });   
    }

    public function profile(){
        $user = Auth::user();
        return view('profile')->with('user', $user);
    }
}
