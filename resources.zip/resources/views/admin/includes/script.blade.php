
	<!-- Bottom scripts (common) -->
	<script src="{{asset('public/admin/js/gsap/TweenMax.min.js')}}"></script>
	<script src="{{asset('public/admin/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js')}}"></script>
	<script src="{{asset('public/admin/js/bootstrap.js')}}"></script>
	<script src="{{asset('public/admin/js/joinable.js')}}"></script>
	<script src="{{asset('public/admin/js/resizeable.js')}}"></script>
	<script src="{{asset('public/admin/js/neon-api.js')}}"></script>
	<script src="{{asset('public/admin/js/jvectormap/jquery-jvectormap-1.2.2.min.js')}}"></script>


	<!-- Imported scripts on this page -->
	<script src="{{asset('public/admin/js/jvectormap/jquery-jvectormap-europe-merc-en.js')}}"></script>
	<script src="{{asset('public/admin/js/jquery.sparkline.min.js')}}"></script>
	<script src="{{asset('public/admin/js/rickshaw/vendor/d3.v3.js')}}"></script>
	<script src="{{asset('public/admin/js/rickshaw/rickshaw.min.js')}}"></script>
	<script src="{{asset('public/admin/js/raphael-min.js')}}"></script>
	<script src="{{asset('public/admin/js/morris.min.js')}}"></script>
	<script src="{{asset('public/admin/js/toastr.js')}}"></script>
	<script src="{{asset('public/admin/js/neon-chat.js')}}"></script>


	<!-- JavaScripts initializations and stuff -->
	<script src="{{asset('public/admin/js/neon-custom.js')}}"></script>


	<!-- Demo Settings -->
	<script src="{{asset('public/admin/js/neon-demo.js')}}"></script>