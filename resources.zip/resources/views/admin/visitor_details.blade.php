<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="description" content="Neon Vendor Panel" />
	<meta name="author" content="" />

	<title>Team rondo | Member's details</title>
	@include('admin.includes.head')

</head>
<body class="page-body  page-fade" data-url="http://neon.dev">
<?php 
function months($date1, $date2)
{
    
$ts1 = strtotime($date1);
$ts2 = strtotime($date2);

$year1 = date('Y', $ts1);
$year2 = date('Y', $ts2);

$month1 = date('m', $ts1);
$month2 = date('m', $ts2);

$diff = (($year2 - $year1) * 12) + ($month2 - $month1);

    return $diff;
}
?>

<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
	@include('admin.includes.sidemenu')
	<div class="main-content">
		@include('admin.includes.header')
		<hr />
		
		<div class="row">
			<div class="col-xs-12">
				<div class="col-xs-8">
					<ol class="breadcrumb bc-3">
						<li>
							<a href="{{url('admin/index')}}"><i class="fa-home"></i>Dashboard</a>
						</li>
						<li class="active">
							<a href="#">Member's Transactions</a>
						</li>
					</ol>
				</div>
				<div class="col-xs-4">
					<div class="pull-right">
							{{--<a href="{{url('admin/new_customer')}}" class="btn btn-primary"><i class="entypo-user"> </i> Add new</a>--}}
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<table style="width: 100%;">
							<tr>
								<td class="grey">
									First name
								</td>
								@if($visitor->first_name !== null || $visitor->first_name != "")
								<td class="light">
										{{$visitor->first_name}} 
								</td>
								@else
								<td class="light">
										NO FIRST NAME PROVIDED
								</td>
								@endif
							</tr>
							<tr>
							    <td class="grey">
									Last name
								</td>
								@if($visitor->last_name !== null || $visitor->last_name != "")
								<td class="light">
										{{$visitor->last_name}}
								</td>
								@else
								<td class="light">
										NO LAST NAME PROVIDED
								</td>
								@endif
							</tr>
							<tr>
								<td class="grey">
									Phone
								</td>
									@if($visitor->phone != null || $visitor->phone != "")
								<td class="light">
										{{$visitor->phone}} 
								</td>
								@else
								<td class="light">
										NO PHONE PROVIDED
								</td>
								@endif
							</tr>
							<tr>
								<td class="grey">
									Address
								</td>
									@if($visitor->address != null || $visitor->address != "")
								<td class="light">
										{{$visitor->address}}
								</td>
								@else
								<td class="light">
										NO ADDRESS PROVIDED
								</td>
								@endif
							</tr>
							<tr>
								<td class="grey">
									Email
								</td>
									@if($visitor->email != null || $visitor->email != "")
								<td class="light">
										{{$visitor->email}} 
								</td>
								@else
								<td class="light">
										NO EMAIL PROVIDED
								</td>
								@endif
							</tr>
							<tr>
								<td class="grey">
									Date of birth
								</td>
								<td class="light">
										{{$visitor->dob}} 
								</td>
							</tr>
							<tr>
								<td class="grey">
									Team ID
								</td>
								<td class="light">
										{{$visitor->team_id}} 
								</td>
							</tr>
							<tr>
								<td class="grey">
									Lead ID number
								</td>
								<td class="light">
										{{$visitor->id_number}} 
								</td>
							</tr>
							<tr>
								<td class="grey">
									Team Lead
								</td>
								<td class="light">
										{{$visitor->member_first_name}} {{$visitor->member_last_name}} 
								</td>
							</tr>
							
							<tr>
								<td class="grey">
									Bank
								</td>
								<td class="light">
										{{$visitor->bank}} 
								</td>
							</tr>
							<tr>
								<td class="grey">
									Account name
								</td>
								<td class="light">
										{{$visitor->bank_account_name}} 
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Account number
								</td>
								<td class="light">
										{{$visitor->bank_account_number}} ({{$visitor->bank_account_type}})
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Branch
								</td>
								<td class="light">
										{{$visitor->branch_name}} 
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Branch bcode
								</td>
								<td class="light">
										{{$visitor->branch_code}} 
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Account number
								</td>
								<td class="light">
										{{$visitor->bank_account_number}} ({{$visitor->bank_account_type}})
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Partner 
								</td>
								<td class="light">
										{{$visitor->partner_name}} 
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Partner's phone 
								</td>
								<td class="light">
										{{$visitor->partner_phone}}
								</td>
								
							</tr>
							<tr>
								<td class="grey">
									Countdown
								</td>
									@if(count($subscriptions) > 0)
								<td class="light">
										<?php echo months($subscriptions[0]->created_at, date("Y-m-d")); ?> month
								</td>
								@else
								<td class="light">
										NO SUBSCRIPTION YET
								</td>
								@endif
							</tr>
							<tr>
								<td class="grey">
									Certificate
								</td>
								
								<td class="light">
								    <a href="{{url('admin/certificate/'.$visitor->id)}}" >Download</a>
								</td>
							</tr>
						</table>
					</div>
					{{--
					<div class="col-md-6">
					    <form role="form" method="post" action="{{url('admin/send_certificate')}}" class="form-horizontal form-groups-bordered">
        					{{ csrf_field() }}
        					<div class="form-group">
        					<div class="col-sm-12">
        							<input type="text" name="name" class="form-control" value="{{$visitor->first_name}} {{$visitor->last_name}}" readonly>
        						</div>
        					</div>
        					<div class="form-group">
        						<div class="col-sm-12">
        							<input type="text" name="email" class="form-control" value="{{$visitor->email}}" readonly>
        						</div>
        					</div>
        					<div class="form-group">
        						<div class="col-sm-12">
        							<input type="file" name="certificate" class="form-control"  accept="application/pdf">
        						</div>
        					</div>
					        <div class="form-group">
        						<div class=" col-sm-5">
        							<button type="submit" class="btn btn-default">Send mail now</button>
        						</div>
        					</div>
					    </form>
					</div>
					--}}
				</div>
				<br/><h3>Subscriptions</h3>
				<table class="table table-bordered datatable" id="table-1">
					<thead>
						<tr>
							<th>S/N</th>
							<th>Amount</th>
							<th>Date</th>
							<th>Expiry date</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						@foreach($subscriptions as $key=>$subscription)
						<tr class="odd gradeX">
							<td>{{$subscription->key + 1}}</td>
							<td>N{{number_format($subscription->amount)}}</td>
							<td>{{$subscription->created_at}}</td>
							<td>{{$subscription->expiry_date}}</td>
							@if($subscription->status == 1)
							<td><span class="green">Success</span></td>
							@elseif($subscription->status == 2)
							<td><span class="brown">Failed</span></td>
							@endif
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
		
		<br />
		
		<br />
		
	</div>




	<!-- Imported styles on this page -->
	<link rel="stylesheet" href="{{asset('public/admin/js/jvectormap/jquery-jvectormap-1.2.2.css')}}">
	<link rel="stylesheet" href="{{asset('public/admin/js/rickshaw/rickshaw.min.css')}}">
	<link rel="stylesheet" href="{{asset('public/admin/js/datatables/datatables.css')}}">
	<script src="{{asset('public/admin/js/datatables/datatables.js')}}"></script>
	@include('admin.includes.script')
	<script type="text/javascript">
		jQuery( document ).ready( function( $ ) {
			var $table1 = jQuery( '#table-1' );
			
			// Initialize DataTable
			$table1.DataTable( {
				"aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
				"bStateSave": true,
				
			});
			
			
		} );
	</script>
</body>
</html>