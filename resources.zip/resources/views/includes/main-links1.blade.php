<ul class="navbar-nav mx-auto navbar-center" >
    <li class="nav-item active">
    <a href="{{ url('visitors/member/'.$loggedInUser->member_id) }}" class="nav-link">Team Home</a>
    </li>
    <li class="nav-item">
    <a href="#" class="nav-link">Welcome {{ $loggedInUser->first_name }} {{ $loggedInUser->last_name }} (Visitor)</a>
    </li>
    
    <li class="nav-item">
    <a href="{{url('visitors/profile')}}" class="nav-link">Profile</a>
    </li>
    <li class="nav-item"><a href="{{url('visitors/appointments')}}" class="nav-link" >Book Appointments</a></li>
    <li class="nav-item"><a href="{{url('visitors/comments')}}" class="nav-link" >Comment on team lead</a></li>
    <li class="nav-item"><a href="{{url('visitors/certificate')}}" class="nav-link" >Your certificate</a></li>
    
    
    
    <!--
    <li class="nav-item">
    <a href="learning.html" class="nav-link">Courses</a>
    </li>
    -->
    {{-- 
    <li class="nav-item">
    <a href="#pricing" class="nav-link">Pricing</a>
    </li>
    <li class="nav-item">
    <a href="#contact" class="nav-link">Contact Us</a>
    </li>
    --}}
</ul>
<ul class="navbar-nav navbar-center">
    @if(Auth::user())
    <li class="nav-item">
    <a href="{{url('login')}}" class="nav-link" >Login</a>
    </li>
     @else
    <li class="nav-item">
    <a href="{{url('logout')}}" class="nav-link" >Logout</a>
    </li>
    @endif
    <!--
    <li class="nav-item">
    <a href="#login" class="nav-link" data-toggle="modal" data-target="#exampleModalCenter-1">Register</a>
    </li>
-->
</ul>
<script src="{{asset('public/main/js/jquery.min.js')}}"></script>
@if(Session::has('success'))
<script type="text/javascript">
    $(document).ready(function()
    {
        // Sample Toastr Notification
        setTimeout(function()
        {
            var opts = {
                "closeButton": true,
                "debug": false,
                "positionClass": "toast-top-right",
                "toastClass": "black",
                "onclick": null,
                "showDuration": "30000",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
    
            toastr.success("{{Session::get('success')}}", opts);
        }, 0);
    });
</script>
@endif

@if(Session::has('error'))
<script type="text/javascript">
    $(document).ready(function()
    {
        // Sample Toastr Notification
        setTimeout(function()
        {
            var opts = {
                "closeButton": true,
                "debug": false,
                "positionClass":  "toast-top-right",
                "toastClass": "black",
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
    
            toastr.success("{{Session::get('error')}}", opts);
        }, 10);
    });
</script>
@endif