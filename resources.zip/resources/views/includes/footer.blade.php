
    <!-- Footer Start -->
    <!--
    <section class="footer" style="background-image: url({{asset('public/main/images/footer-bg.png')}})">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="mb-5">
                        <img src="{{asset('public/main/images/logo-light.png')}}" alt="" class="" height="24">
                        <p class="text-white-50 my-4 font-size-15">Cras ultricies mi eu turpis sit hendrerit fringilla vestibulum ante ipsum primis in faucibus ultrices posuere cubilia.</p>
                        <ul class="list-inline footer-social-icon-content">
                            <li class="list-inline-item mr-4"><a href="#" class="footer-social-icon"><i class="" data-feather="facebook"></i></a></li>
                            <li class="list-inline-item mr-4"><a href="#" class="footer-social-icon"><i class="" data-feather="twitter"></i></a></li>
                            <li class="list-inline-item mr-4"><a href="#" class="footer-social-icon"><i class="" data-feather="instagram"></i></a></li>
                            <li class="list-inline-item"><a href="#" class="footer-social-icon"><i class="" data-feather="linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-7 offset-lg-1">
                    <div class="row">
                        <div class="col-md-4">
                            <h6 class="text-white text-uppercase mb-4">About Us</h6>
                            <ul class="list-unstyled footer-sub-menu">
                                <li><a href="#" class="footer-link">Works</a></li>
                                <li><a href="#" class="footer-link">Strategy</a></li>
                                <li><a href="#" class="footer-link">Releases</a></li>
                                <li><a href="#" class="footer-link">Press</a></li>
                                <li><a href="#" class="footer-link">Mission</a></li>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h6 class="text-white text-uppercase mb-3">Customers</h6>
                            <ul class="list-unstyled footer-sub-menu">
                                <li><a href="#" class="footer-link">Tranding</a></li>
                                <li><a href="#" class="footer-link">Popular</a></li>
                                <li><a href="#" class="footer-link">Customers</a></li>
                                <li><a href="#" class="footer-link">Features</a></li>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h6 class="text-white text-uppercase mb-3">Support</h6>
                            <ul class="list-unstyled footer-sub-menu">
                                <li><a href="#" class="footer-link">Developers</a></li>
                                <li><a href="#" class="footer-link">Support</a></li>
                                <li><a href="#" class="footer-link">Customer Service</a></li>
                                <li><a href="#" class="footer-link">Get Started</a></li>
                                <li><a href="#" class="footer-link">Guide</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    -->
    <div class="footer-alt py-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center">
                        <p class="text-white-50 font-size-15 mb-0">2020 © TeamRondo solution. Design By <a href="#"/>Optisoft</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->