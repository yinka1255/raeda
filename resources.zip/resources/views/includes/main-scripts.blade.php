 <!-- javascript -->
    
    <script src="{{asset('public/main/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('public/main/js/scrollspy.min.js')}}"></script>
    <script src="{{asset('public/main/js/jquery.easing.min.js')}}"></script>
    <!-- feather icon -->
    <script src="{{asset('public/main/js/feather.js')}}"></script>
    <!-- unicons icon -->
    <script src="{{asset('public/main/js/unicons.js')}}"></script>
    <!-- Main Js -->
    <script src="{{asset('public/main/js/app.js')}}"></script>
