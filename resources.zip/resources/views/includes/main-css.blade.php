<link rel="shortcut icon" href="{{asset('public/main/images/favicon.ico')}}">

<!-- css -->
<link href="{{asset('public/main/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('public/main/css/materialdesignicons.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('public/main/css/style.min.css')}}" rel="stylesheet" type="text/css" />
