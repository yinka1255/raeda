<ul class="navbar-nav mx-auto navbar-center" >
    @if(Request::segment(2) == "")
    <li class="nav-item active">
    <a href="{{url('/')}}" class="nav-link">Home</a>
    </li>
    <li class="nav-item">
    <a href="{{url('about')}}" class="nav-link">About</a>
    </li>
    <!--
    <li class="nav-item">
    <a href="learning.html" class="nav-link">Courses</a>
    </li>
    -->
    <li class="nav-item">
    <a href="{{ url('/#pricing') }}" class="nav-link">Pricing</a>
    </li>
    <li class="nav-item">
    <a href="{{ url('/#contact')}}" class="nav-link">Contact Us</a>
    </li>
    @endif
</ul>
<ul class="navbar-nav navbar-center">
    {{--
    <li class="nav-item">
    <a href="{{url('login')}}" class="nav-link" >Member area</a>
    </li>
    --}}
    @if(Auth::user())
    <li class="nav-item"><a href="{{url('members/profile')}}" class="nav-link" >Profile</a></li>
    <li class="nav-item"><a href="{{url('members/visitors')}}" class="nav-link">Visitors</a></li>
    <li class="nav-item"><a href="{{url('members/appointments')}}" class="nav-link">Appointments</a></li>
    <li class="nav-item"><a href="{{url('members/broadcasts')}}" class="nav-link">Broadcasts</a></li>
    <li class="nav-item">
    <a href="{{url('logout')}}" class="nav-link" >Logout</a>
    </li>
    @else
    <li class="nav-item">
    <a href="{{url('login')}}" class="nav-link" >Login</a>
    </li>
    @endif
    <!--
    <li class="nav-item">
    <a href="#login" class="nav-link" data-toggle="modal" data-target="#exampleModalCenter-1">Register</a>
    </li>
-->
</ul>
<script src="{{asset('public/main/js/jquery.min.js')}}"></script>
@if(Session::has('success'))
<script type="text/javascript">
    $(document).ready(function()
    {
        // Sample Toastr Notification
        setTimeout(function()
        {
            var opts = {
                "closeButton": true,
                "debug": false,
                "positionClass": "toast-top-right",
                "toastClass": "black",
                "onclick": null,
                "showDuration": "30000",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
    
            toastr.success("{{Session::get('success')}}", opts);
        }, 0);
    });
</script>
@endif

@if(Session::has('error'))
<script type="text/javascript">
    $(document).ready(function()
    {
        // Sample Toastr Notification
        setTimeout(function()
        {
            var opts = {
                "closeButton": true,
                "debug": false,
                "positionClass":  "toast-top-right",
                "toastClass": "black",
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
    
            toastr.success("{{Session::get('error')}}", opts);
        }, 10);
    });
</script>
@endif