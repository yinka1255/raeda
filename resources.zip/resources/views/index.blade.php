<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    <!-- favicon -->
    @include('includes.main-css')
</head>

<body>

    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->
        <!--Navbar Start-->
        <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
            <div class="container">
                <!-- LOGO -->
                <a class="navbar-brand logo" href="{{url('/')}}">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                @include('includes.main-links')
                </div>
            </div>
        </nav>
        <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="hero-6-bg position-relative" style="background-image: url({{asset('public/main/images/hero-6-bg-img.jpg')}}); padding-top: 160px !important;padding-bottom: 67px !important; height: 750px" id="home">
         <div class="bg-overlay"></div> 
        <div class="container" style="margin-top: 50px;">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center">
                        <h1 class="text-white hero-6-title mb-4 line-height-1_4">Building Network Marketing Business Shouldn’t be So difficult.</h1>
                        <p class="text-white-50 w-75 mx-auto font-size-15">With TeamRondo Solution software, you can now build a professional business with absolutely no stress.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8 ">
                    <div class="text-center Subcribe-form mt-5">
                        <form action="#">
                            <input type="text" placeholder="Enter your Email...">
                            <button type="submit" class="btn rounded-pill btn-primary ml-2 mt-4 mt-sm-0">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->

    <!-- Why Choose Us Start -->
    <section class="section" >
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4">
                    <div class="mb-4 mb-lg-0">
                        <div class="p-2 bg-soft-primary d-inline-block rounded mb-4">
                            <div class="icon-xxl uim-icon-primary"><i class="uim uim-cube"></i></div>
                        </div>
                        <h3 class="">TeamRondo Solution Mission</h3>
                        <p class=" mb-4">TeamRondo solution’s mission is to enable existing, and wanna be business consultant in Team Rondo Dynasty 
                            and the entire Neo Life family to grow their MLM business professionally, and achieve their goals — quickly and easily..</p>
                        <!-- <a href="#" class="btn btn-outline-primary">Learn More</a> -->
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="wc-box rounded text-center wc-box-primary p-4 mt-md-5">
                                <div class="wc-box-icon">
                                    <i class="mdi mdi-collage"></i>
                                </div>
                                <h5 class="font-weight-bold mb-2 wc-title mt-4">Esay To Use</h5>
                                <p class="mb-0 font-size-15 wc-subtitle">Networkers do not need to brake a single sweat trying to find prospect.</p>
                            </div>
                            <div class="wc-box rounded text-center wc-box-primary p-4">
                                <div class="wc-box-icon">
                                    <i class="mdi mdi-trending-up"></i>
                                </div>
                                <h5 class="font-weight-bold mb-2 wc-title mt-4">Grow Your Network</h5>
                                <p class="mb-0 font-size-15 wc-subtitle">Makes people enjoy the juicy parts of being part of the Neo Life's family​.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wc-box rounded text-center wc-box-primary p-4">
                                <div class="wc-box-icon">
                                    <i class="mdi mdi-security"></i>
                                </div>
                                <h5 class="font-weight-bold mb-2 wc-title mt-4">Designed for Networkers</h5>
                                <p class="mb-0 font-size-15 wc-subtitle">Professionally designed with every networkers in mind.</p>
                            </div>
                            <div class="wc-box rounded text-center wc-box-primary p-4">
                                <div class="wc-box-icon">
                                    <i class="mdi mdi-database-lock"></i>
                                </div>
                                <h5 class="font-weight-bold mb-2 wc-title mt-4">Secure a better Life</h5>
                                <p class="mb-0 font-size-15 wc-subtitle">Network business opportunity is extremely certain to change anyone’s life for better.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Why Choose Us End -->

    <!-- Features Start -->
    <section class="section feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img-1.png')}})">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="text-center mb-5">
                        <h3 class="title mb-3">Awesome Features</h3>
                        <p class="font-size-15">Teamrondo Solution has salvaged the challenge of network marketers roaming and looking for prospects for the TeamRondo Dynasty and the entire Neo Life family.</p>
                    </div>
                </div>
            </div>
                <section class="section" >
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4">
                    <div class="mb-4 mb-lg-0">
                        <div class="p-2 bg-soft-primary d-inline-block rounded mb-4">
                            <div class="icon-xxl uim-icon-primary"><i class="uim uim-cube"></i></div>
                        </div>
                        <h3 class="">Prospecting Site</h3>
                        <p class=" mb-4">Our prospecting site is a simple 4 pages website that has a predefined template, 
                        but it’s fully customizable and controllable by you. The purpose of this 4 page prospecting site is to systematically attract visitor, 
                        professionally present your business to educate the visitor and robustly qualify and convert them to prospects.</p>
                        <!-- <a href="#" class="btn btn-outline-primary">Learn More</a> -->
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="mb-4 mb-lg-0">
                        <div class="p-2 bg-soft-primary d-inline-block rounded mb-4">
                            <div class="icon-xxl uim-icon-primary"><i class="uim uim-cube"></i></div>
                        </div>
                        <h3 class="">MLM Contact Manager</h3>
                        <p class=" mb-4">Our Web based MLM contact Management software makes it easy to track names, Phone numbers, state, region 
                        and all kinds of other important informations about your prospects.
Our interface makes it easy to keep notes on each and every potential prospect/customer and easily set the next follow up date for this contact.</p>
                        <!-- <a href="#" class="btn btn-outline-primary">Learn More</a> -->
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="mb-4 mb-lg-0">
                        <div class="p-2 bg-soft-primary d-inline-block rounded mb-4">
                            <div class="icon-xxl uim-icon-primary"><i class="uim uim-cube"></i></div>
                        </div>
                        <h3 class="">MLM Autoresponder</h3>
                        <p class=" mb-4"> our Teamrondo Solution's prospecting software is simply a series of emails that you can send out to 
                        someone on a timed basis. So you can enter all the content of the emails that follow up or 
                        train a prospect or your team, and also set at what intervals you would like the email to be sent out.</p>
                        <!-- <a href="#" class="btn btn-outline-primary">Learn More</a> -->
                    </div>
                </div>
                </div>
                </div>
                </section>
            
        </div>
    </section>
    <section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="mb-4 mb-lg-0">
                        <img src="{{asset('public/main/images/features-img.png')}}" alt="" class="img-fluid d-block mx-auto">
                    </div>
                </div>

                <div class="col-lg-5 offset-lg-1">
                    <p class="font-weight-medium text-uppercase mb-2"><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> Solution</p>
                    <h3 class="font-weight-semibold line-height-1_4 mb-4"><b>professionally</b> designed with every <b>networkers</b> in mind</h3>
                    <p class=" font-size-15 mb-4">The TeamRondo Solution prospecting software has been professionally designed with every networkers in mind</p>
                    <p class=" font-size-15 mb-4">Now, Networkers do not need to brake a single sweat trying to find prospect for their business. The leader has made sure all his team members can now have more prospect than they can handle using the Teamrondo Solution Prospecting tool.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features End -->

    <!-- Pricing Start -->
    <section class="section bg-light" id="pricing">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="text-center mb-5">
                        <h3 class="title mb-3">Teamrondo Solution’s Pricing</h3>
                        <p class=" font-size-15">We have different plans for different categories of TeamRondo Dynasty both the beginners, the averagely successful and the big fish of our team.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                @foreach($plans as $plan)
                @if($plan->id != 6 && $plan->id != 2 )
                <div class="col-lg-3">
                    <div class="pricing-box rounded text-center p-4">
                        <div class="pricing-icon-bg my-4">
                            <i class="mdi mdi-account h1"></i>
                        </div>
                        <h4 class="title mb-3" style="font-size: 19px;">{{$plan->name}}</h4>
                        <h1 class="font-weight-bold mb-0"><b><sup class="h4 mr-2 font-weight-bold">NGN</sup>{{number_format($plan->amount)}}</b></h1>
                        <p class="text-muted font-weight-semibold">{{($plan->days) / 30}} months</p>
                        <ul class="list-unstyled pricing-item mb-4">
                            <!--<li class="text-muted">N30,000 worth of products</li>-->
                            <li class="text-muted">Support: Yes</li>
                        </ul>
                        <a href="{{url('members/profile')}}" class="btn btn-outline-primary pr-btn">Buy Now</a>
                        <div class="mt-4">
                            <div class="hero-bottom-img">
                                <img src="{{asset('public/main/images/pricing-bottom-bg.png')}}" alt="" class="img-fluid d-block mx-auto">
                            </div>
                        </div>
                    </div>
                </div>
                @endif
                @endforeach
                {{--
                <div class="col-lg-4">
                    <div class="pricing-box rounded text-center active p-4">
                        <div class="pricing-icon-bg my-4">
                            <i class="mdi mdi-account-multiple h1"></i>
                        </div>
                        <h4 class="title mb-3">Basic</h4>
                        <h1 class="font-weight-bold mb-0"><b><sup class="h4 mr-2 font-weight-bold">NGN</sup>6600</b></h1>
                        <p class="text-muted font-weight-semibold">6 / Month</p>
                        <ul class="list-unstyled pricing-item mb-4">
                            <li class="text-muted">Subscription: NGN2000</li>
                            <li class="text-muted">Monthly renewal: NGN1500 </li>
                            <li class="text-muted">Support: Yes</li>
                        </ul>
                        <div class="mt-4">
                            <div class="hero-bottom-img">
                                <img src="{{asset('public/main/images/pricing-bottom-bg.png')}}" alt="" class="img-fluid d-block mx-auto">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="pricing-box rounded text-center p-4">
                        <div class="pricing-icon-bg my-4">
                            <i class="mdi mdi-account-group h1"></i>
                        </div>
                        <h4 class="title mb-3">Pro</h4>
                        <h1 class="font-weight-bold mb-0"><b><sup class="h4 mr-2 font-weight-bold">NGN</sup>9000</b></h1>
                        <p class="text-muted font-weight-semibold">12 / Month</p>
                        <ul class="list-unstyled pricing-item mb-4">
                            <li class="text-muted">Subsription: NGN2000</li>
                            <li class="text-muted">Monthly renewal: NGN1500 </li>
                            <li class="text-muted">Support: Yes</li>
                        </ul>
                        <div class="mt-4">
                            <div class="hero-bottom-img">
                                <img src="{{asset('public/main/images/pricing-bottom-bg.png')}}" alt="" class="img-fluid d-block mx-auto">
                            </div>
                        </div>
                    </div>
                </div>
                --}}
            </div>
        </div>
    </section>
    <!-- Pricing End -->

    <!-- Blog start -->
    <section class="section" id="blog">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="text-center mb-5">
                        <h3 class="title mb-3">Our Team</h3>
                        <p class="font-size-15">TeamRondo Solutions is made up of great minds. </p>
                    </div>
                </div>
            </div>

            <div class="row text-center">
                <div class="col-lg-3 pricing-box">
                    <div class="blog-box mb-4 mb-lg-0">
                        <img src="{{asset('public/main/images/img3.jpeg')}}" alt="" class="img-fluid d-block mx-auto rounded">
                        <br/>
                        <a href="#" class="text-dark font-weight-bold h5">Remi Adepoju </a>
                        <br/>
                        <p class="text-muted font-size-15">CEO & Founder </p>
                    </div>
                </div>
                <div class="col-lg-3 pricing-box">
                    <div class="blog-box blog-box mb-4 mb-lg-0">
                        <img src="{{asset('public/main/images/img1.jpeg')}}" alt="" class="img-fluid d-block mx-auto rounded">
                        <br/>
                        <a href="#" class="text-dark font-weight-bold h5">Muibat Adepoju</a>
                        <br/>
                        <p class="text-muted font-size-15">Customer support Manager</p>
                    </div>
                </div>
                <div class="col-lg-3 pricing-box">
                    <div class="blog-box blog-box mb-4 mb-lg-0">
                        <img src="{{asset('public/main/images/img2.jpeg')}}" alt="" class="img-fluid d-block mx-auto rounded">
                        <br/>
                        <a href="#" class="text-dark font-weight-bold h5">Wale Adepoju</a>
                        <br/>
                        <p class="text-muted font-size-15">Sales & Business Manager</p>
                    </div>
                </div>
                <div class="col-lg-3 pricing-box">
                    <div class="blog-box blog-box mb-4 mb-lg-0">
                        <img src="{{asset('public/admin/images/avatar.jpg')}}" alt="" class="img-fluid d-block mx-auto rounded">
                        <br/>
                        <a href="#" class="text-dark font-weight-bold h5">Folami Olabiyi</a>
                        <br/>
                        <p class="text-muted font-size-15">Developer</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog End -->

    <!-- Contact Us Start -->
    <section class="section bg-light" id="contact">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="text-center mb-5">
                        <h3 class="title mb-3">Contact Us</h3>
                        <p class="font-size-15">We appreciate your interest in our business. Please use the guide below to direct your enquiry. Our team will reply within 1-2 business days.</p>
                    </div>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <div class="custom-form mb-5 mb-lg-0">
                        <div id="message"></div>
                        <form method="post" action="php/contact.php" name="contact-form" id="contact-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Name*</label>
                                        <input name="name" id="name" type="text" class="form-control" placeholder="Your name...">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email Address*</label>
                                        <input name="email" id="email" type="email" class="form-control" placeholder="Your email...">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label for="comments">Message*</label>
                                        <textarea name="comments" id="comments" rows="4" class="form-control" placeholder="Your message..."></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <button type="submit" id="submit" name="send" class="btn btn-primary">Send Message <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                                    <div id="simple-msg"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="contact-detail text-muted ml-lg-5">
                        <p class=""><i class="icon-xs icon mr-1" data-feather="mail"></i> : <span>support@teamrondo.com</span></p>
                        <p class=""><i class="icon-xs icon mr-1" data-feather="mail"></i> : <span>sales@teamrondo.com</span></p>
                        <p class=""><i class="icon-xs icon mr-1" data-feather="link"></i> : <span>www.website.com</span></p>
                        <p class=""><i class="icon-xs icon mr-1" data-feather="phone-call"></i> : <span>+234 (813) 0973748 </span></p>
                        <p class=""><i class="icon-xs icon mr-1" data-feather="clock"></i> : <span>9:00 AM - 5:00 PM</span></p>
                        <p class=""><i class="icon-xs icon mr-1" data-feather="map-pin"></i> : <span>Offa, Kwara State, 
                            Nigeria.</span></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Us End -->

    @include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>