<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Video page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    
</head>

<body>
<script src="{{asset('public/main/js/jquery.min.js')}}"></script>

    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="index.html">
                <img src="images/logo-dark.png" alt="" class="logo-dark" height="24" />
                <img src="images/logo-light.png" alt="" class="logo-light" height="24" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            {{-- @include('includes.main-links1') --}}
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-8">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">Welcome to <b>Team {{$team->team_id}}'s @if($team->first_name != null)({{$team->first_name}}).@endif</b> page</b>. </h3>
                    <p class="text-muted font-size-15 mb-4"> </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">Our presentation</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row ">
            <div class="col-lg-7 ">
            <p>Your first step is to go through our onboarding video. Click the register button afterwards or login to continue if your have registered before </p>
                <video width="100%" height="auto" controls>
                    <source src="{{asset('public/main/videos/video.mp4')}}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
            <div class="col-lg-5">
                <div class="mb-4 mb-lg-0">
                    <img src="{{asset('public/main/images/features-img.png')}}" alt="" class="img-fluid d-block mx-auto">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-7" style="display: inline-block;">
                @if(count($subscriptions) >0)
                <a href="{{url('visitors/login/'.$team->id_number)}}" class="btn btn-primary pull-right">Login</a>
                <a href="{{url('visitors/register/'.$team->id_number)}}" class="btn btn-danger pull-right">Regsiter</a>
                @else
                <p style="color: red">This team's subscription has expired. Kindly check back later or call +234 (813) 0973748 to get onboarded</p>
                @endif
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-7" style="display: inline-block;margin-left: 50px;margin-top: 50px;">
            <h3>Reviews</h3>
            <table class="table table-bordered datatable" id="table-1">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Client Name</th>
                        <th>Team ID</th>
                        <th>Comment</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($comments as $key=>$comment)
                    <tr class="odd gradeX">
                        <td>{{$key + 1}}</td>
                        <td>{{$comment->visitor_first_name}} {{$comment->visitor_last_name}}</td>
                        <td>{{$comment->member_team_id}}</td>
                        <td>{{$comment->message}}</td>
                        <td>{{ date('d-m-Y', strtotime($comment->created_at)) }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</section>
<!-- Features End -->


    @include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>