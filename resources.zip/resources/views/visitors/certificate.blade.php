<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TeamRondo Certificate</title>
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans:400,600" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/main/css/cert-style.css')}}">
    <style>
        @media print {
            #print: {
                display: none !important;
            }
        
        }
    </style>
</head>
<body>
  <section class = ".center">
    <center>
      <br><br><br><br><br>
<h1 id="cert-title" ></h1>
  TeamRondo Dynasty in partnership with Cooperate Business Consultancy
</h1>
<br>

<p class=".center smaller" id="cert-declaration">
  hereby certifies that
</p>
<br><br>
<h1 id="cert-holder">
  {{$loggedInUser->first_name}} {{$loggedInUser->last_name}}
</h1>
<br><br>
<p class="smaller" id='cert-completed-line'>
  has successfully completed the following courses
</p>

<h3 id="cert-course">
  Which includes:
</h3>

 <div id="cert-desc">
  <p class="smaller" id='cert-details'>
    INTRO. TO ENTREPRENUERSHIP
    <br/>DIFFERENT SOURCES OF INCOME
    <br/>PERSONAL MISSION STATEMENT
    <br/>PRINCIPLES OF GOAL SETTING
    <br/>PRINCIPLES OF MARKETING
  </p>
</div> 

<br>
<p id="cert-from" class="smaller">
  &nbsp; As part of the TeamRondo dynasty and Cooperate Business Consultancy Program
</p>

 <br>
<p class="smaller" id='cert-issued'>
 <b>Issued on:</b> {{$date}}.
</p>

<div id="cert-footer" style="margin-top: 30px;">
  
  <div id="cert-ceo-design">
      
    <img id="cert-ceo-sign" src="{{asset('public/main/images/sig.png')}}" alt="picture of stamp">
    
    <hr>
    <p>Remi Adepoju</p>
    <br/>
    <b>CERT NO:</b> {{strtotime($loggedInUser->created_at)}}
  </div>
</div> 
</center>
</section>
<button onclick="window.print()" id="print" style="position: absolute; bottom: 30px;" >Print/Save</button>

<!-- <div id="cert-verify">
    Verify at companywebsite.ai/verify/XYZ12ER56129F. <br> 
    Company has confirmed the participation of this individual in the course.
  </div> -->
</body>

</html>


