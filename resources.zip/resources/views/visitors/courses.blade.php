<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Courses page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    
</head>

<body>
<script src="{{asset('public/main/js/jquery.min.js')}}"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="index.html">
                <img src="images/logo-dark.png" alt="" class="logo-dark" height="24" />
                <img src="images/logo-light.png" alt="" class="logo-light" height="24" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            {{-- @include('includes.main-links1')--}}
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-8">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">Course {{$course->id}} of 5</h3>
                    <p class="text-muted font-size-15 mb-4">You must study the content on this page and score at least 60% in the test below. </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">{{$course->title}}</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row">
            <div class="col-md-6">
                <div class="row ">
                    @if($passed != null)
                    @php
                        $next_course = $course->id + 1;
                    @endphp
                    <div class="col-sm-12" style="display: inline-block;">
                        <p style="color: green">You have passed course {{$course->id}}. Now you can proceed to course {{$next_course}}</p>
                        <a href="{{url('visitors/courses/'.$next_course)}}" class="btn btn-primary pull-right" style="float: right;">Proceed >></a>
                    </div>
                    @elseif(count($sat) > 0)
                    <div class="col-sm-12" style="display: inline-block;">
                        <p style="color: red">You have scored below 60% in all your attempt. Try again</p>
                    </div>
                    @endif
                </div>
                <p><b>Read the following content carefully.</b></p>
                {!! $course->content !!}
            </div>
            <div class="col-md-5">
                <div class="mb-4 mb-lg-0">
                    <img src="{{asset('public/main/images/features-img.png')}}" alt="" class="img-fluid d-block mx-auto">
                </div>
            </div>
        </div>
        <div class="row ">
            @if($passed != null)
                @php
                    $next_course = $course->id + 1;
                @endphp
                <div class="col-sm-7" style="display: inline-block;">
                    <p style="color: green">You have passed course {{$course->id}}. Now you can proceed to course {{$next_course}}</p>
                    <a href="{{url('visitors/courses/'.$next_course)}}" class="btn btn-primary pull-right" style="float: right;">Proceed >></a>
                </div>
            @endif
            @if($course->id == 4)
                <b>ASSIGNMENT</b>

                <p>Based on the 5 step plan above, develop your Personal Mission Statement. Write it in your diary or anywhere you can see it always.
                    <br/>

                It is a personal mission statement, so you are not required to submit this to us. Discuss your personal mission statement with your Accountability Partner (AP) 
                <br/>
                As you continue with this program as a Business Consultant Graduate (BCG), subsequent exercises will be based on this one, so make sure you complete it and write your mission statement down.
                </p>
                @php
                    $next_course = $course->id + 1;
                @endphp
                <div class="col-sm-7" style="display: inline-block;">
                    <p style="color: green">Proceed to course {{$next_course}}</p>
                    <a href="{{url('visitors/courses/'.$next_course)}}" class="btn btn-primary pull-right" style="float: right;">Proceed >></a>
                </div>
            @endif
            @if($course->id == 5)
                <b>ASSIGNMENT</b><br/>

                <p>This assignment is very critical. First, download a goal planning template from this link here. 
                <br/>
                Click <a href="{{url('visitors/ods')}}" >here</a> to download the "GOAL SETTING TEMPLATE"
                <br/>
                Use this template to fill out your desired outcomes, and your goals and keep it for referencing.
                </p>
                @php
                    $next_course = $course->id + 1;
                @endphp
                <div class="col-sm-7" style="display: inline-block;">
                    <p style="color: green">Congratulations! You have successfully completed your assessment. </p>
                    <a href="{{url('visitors/info/')}}" class="btn btn-primary pull-right" style="float: right;">Proceed >></a>
                    <a href="{{url('visitors/ods')}}" class="btn btn-danger pull-right" style="float: right;margin-right: 5px;">Download Goal planning template(Compulsory) </a>
                </div>
            @endif
            @if(count($sat) > 0 && $passed == null)
            <div class="col-sm-12" style="display: inline-block;">
                <p style="color: red">You have scored below 60% in all your attempt. Try again</p>
            </div>
            @endif
            @if($passed == null && $course->id != 4 && $course->id != 5)
            <div class="col-sm-12" style="display: inline-block;">
                <h4>Quiz</h4>
                <form method="post" role="form" action="{{url('visitors/answer')}}">
                    {{ csrf_field() }}
                    <input type="hidden" name="course_id" class="form-control" value="{{$course->id}}">
                    @foreach($course_questions as $key=>$course_question)
                        <div class="form-group">
                            <label for="exampleInputEmail1">{{$key+1}} {{". ".$course_question->question}}</label><br/>
                            <input type="radio" name="{{$key}}" class="" value="{{$course_question->id}}_option1" required>
                            <label for="exampleInputEmail1">{{$course_question->option1}}</label><br/>
                            <input type="radio" name="{{$key}}" class="" value="{{$course_question->id}}_option2">
                            <label for="exampleInputEmail1">{{$course_question->option2}}</label><br/>
                            @if($course_question->option3 != "")
                            <input type="radio" name="{{$key}}" class="" value="{{$course_question->id}}_option3">
                            <label for="exampleInputEmail1">{{$course_question->option3}}</label><br/>
                            @else
                            <input type="radio" name="{{$key}}" class="" style="display: none;" value="{{$course_question->id}}_option3">
                            <label for="exampleInputEmail1" style="display: none;">{{$course_question->option3}}</label><br/>
                            @endif
                            @if($course_question->option4 != "")
                            <input type="radio" name="{{$key}}" class="" value="{{$course_question->id}}_option4">
                            <label for="exampleInputEmail1">{{$course_question->option4}}</label><br/>
                            @else
                            <input type="radio" name="{{$key}}" style="display: none;" class="" value="{{$course_question->id}}_option4">
                            <label for="exampleInputEmail1" style="display: none;">{{$course_question->option4}}</label><br/>
                            @endif
                        </div>
                    @endforeach
                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-primary">Submit answer <i class="icon-size-15 icon ml-1" data-feather="arrow-right-circle"></i></button>
                    </div>
                </form>
            </div>
            @endif
        </div>
    </div>
</section>
<!-- Features End -->


    @include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>