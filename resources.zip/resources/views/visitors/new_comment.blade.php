<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | New Comment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
</head>

<body>
<script src="https://js.paystack.co/v1/inline.js"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="index.html">
                <img src="images/logo-dark.png" alt="" class="logo-dark" height="24" />
                <img src="images/logo-light.png" alt="" class="logo-light" height="24" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
             @include('includes.main-links1')
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-5">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">We do the work you <b>stay focused</b> on <b>your customers</b>.</h3>
                    <p class="text-muted font-size-15 mb-4"> </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">New comment</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row ">
            <div class="col-lg-7 ">
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('success'))
                    <p style="color: green">{{Session::get('success')}}</p>
                    @elseif(Session::has('error'))
                    <p style="color: red">{{Session::get('error')}}</p>
                    @endif
                </div>
            </div>
                <form method="post" action="{{url('visitors/create_comment')}}"  >
                {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="title">Message*</label>
                                <textarea name="message" id="comment" type="text" class="form-control" required placeholder="Comment here..." ></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary">Comment <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                            <div id="simple-msg"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-1">
            </div>
            {{--
           <div class="col-lg-4">
                <div class="pull-right">
                    <p style="font-size: 16px;"><b>Links</b></p>
                <ul class="">
                    <li class="mr-4"><a href="{{url('visitors/profile')}}" >Profile</a></li>
                    <li class="mr-4"><a href="{{url('visitors/appointments')}}" >Book Appointments</a></li>
                    <li class="mr-4"><a href="{{url('visitors/comments')}}" >Comment on your team lead</a></li>
                    <li class="mr-4"><a href="{{url('visitors/certificate')}}" >Your certificate</a></li>
                </ul>
                </div>
            </div>
            --}}
        </div>
    </div>
</section>
<!-- Features End -->

<form method="post" style="display: none;" id="paymentForm" action="{{url('members/subscribe')}}" >
                {{ csrf_field() }}
    <input name="transaction_ref" id="transaction_ref" class="form-control" >
    <input name="amount" id="amount" class="form-control" >
    <input name="plan" id="plan" class="form-control" >
</form>

<form>
  <script>
    function payWithPaystack(amount, plan){
      
    var handler = PaystackPop.setup({
      key: "pk_test_377d7219811db755baf173431800c66e3ffdd474",
      email: document.getElementById('email').value,
      amount: amount,
      ref: {{time()}},
      currency: "NGN",
      metadata: {
        custom_fields: [
        { display_name: "Full Names", variable_name: "full_names", value: document.getElementById('name').value },
        { display_name: "Email Address", variable_name: "email_address", value: document.getElementById('email').value },
        { display_name: "Phone", variable_name: "phone", value: document.getElementById('phone').value },
        { display_name: "Plan", variable_name: "plan", value: document.getElementById('plan').value },
        
        ]
      },
      callback: function(response){
        alert('Payment was success. transaction ref is ' + response.reference);
        $("#transaction_ref").val(response.reference);
        var am = amount/100
        $("#amount").val(am);
        $("#plan").val(plan);
        document.getElementById("paymentForm").submit();
        
      },
      onClose: function(){
        alert('Transaction Cancelled');
        
      }
    });
    handler.openIframe();
    }
  </script>
</form>
    @include('includes.footer')
    @include('includes.main-scripts')
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
</body>
</html>