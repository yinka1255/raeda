<!DOCTYPE html>
<html lang="en" style="height: 100%;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    <!-- favicon -->
    @include('includes.main-css')
</head>

<body style="height: 100%;">

    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

        <!--Navbar Start-->
        <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
            <div class="container">
                <!-- LOGO -->
                <a class="navbar-brand logo" href="index.html">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                    <img src="{{asset('public/main/images/logo-light.png')}}" alt="" class="logo-light" height="45" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                @include('includes.main-links')
                </div>
            </div>
        </nav>
        <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/hero-2-bg.jpg')}}); height: 100%;">
        <div class="container" >
            <div class="row align-items-center">
                <!--
                <div class="col-lg-6">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">We do the work you <b>stay focused</b> on <b>your customers</b>.</h3>
                    <p class="text-white font-size-15 mb-4">You are most welcome to the member area. Kindly login with the ID numberand password you must have created. If you are yet to create one, kindly click the register button to register your online account with your team ID.</p>
                    <p class="text-white mb-2"> If you do not have an ID number yet, kindly call us on  +234 (813) 0973748 to get onboarded</p>
                    <div class="mt-5">
                        <a href="{{url('register')}}" class="btn btn-primary mr-2">Get Started</a>
                    </div>
                </div>
                -->
        <!-- Login Modal -->
                <!-- <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden=""> -->
                    <div class="modal-dialog col-lg-5" style="margin-top: 250px;">
                        <div class="modal-content ">
                            <div class="modal-body">
                                <div class="text-center">
                                    <!--<h3 class="title mb-4">Welcome To TeamRondo</h3>-->
                                    <h4 class="text-uppercase text-primary"><b>Password reset</b></h4>
                                </div>
                                <div class="login-form mt-4">
								@if(Session::has('success'))
                                <p style="color: green">{{Session::get('success')}}</p>
                                @elseif(Session::has('error'))
                                <p style="color: red">{{Session::get('error')}}</p>
                                @endif
								<form method="post" role="form" action="{{url('forgot_password_post')}}">
										{{ csrf_field() }}
									<div class="form-group">
										<div class="input-group">
											<div class="input-group-addon">
												<i class="entypo-user"></i>
											</div>
											<input type="email" class="form-control" name="email" placeholder="Email" autocomplete="off" />
										</div>
									</div>
									
									<div class="form-group">
										<button type="submit" class="btn btn-primary btn-block btn-login ">
											<i class="entypo-login"></i>
											Reset password
										</button>
									</div>
									
									<a href="{{url('visitors/login/'.$id_number)}}" class="link">
										<i class="entypo-lock"></i>
										Return to Login Page
									</a>
									
								</form>
                                    
                                    <div class="text-center">
                                        
                                        <p class="text-muted mb-0">New User? <a href="{{url('register')}}" class="text-primary">Signup</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        </div>
                       <!-- End of login Modal -->
                <!-- <div class="col-lg-6 offset-lg-1">
                    <div class="mt-4 mt-lg-0">
                        <img src="images/features-img-1.png" alt="" class="img-fluid d-block mx-auto">
                    </div>
                </div> -->
            </div>
        </div>
    </section>
    <!-- Hero End -->
	@include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>