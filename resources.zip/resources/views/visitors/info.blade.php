<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Information page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    <style>
        #stepContainer {
        width: 300px;
        /*
        position: absolute;
        right: 0;
        top: 0;
        */
        /*background-color: white;*/
        margin-top: 20px;
        }
        .step {
            width: 100%;
            height: 20px;
            border-bottom: 12px solid rgba(0,0,0,0.5);
        }
        tr{
            border: 1px solid #333;
        }
        td{
            border: 1px solid #333;
        }
        th{
            border: 1px solid #333;
        }
        .step:nth-child(1) { height :30px; background-color: blue; margin-left: 280px;color: #fff;}
        .step:nth-child(2) { height :30px; background-color: green;  margin-left: 260px;color: #fff;}
        .step:nth-child(3) { height :30px; background-color: aqua;  margin-left: 240px;color: #fff;}
        .step:nth-child(4) { height :30px; background-color: red;  margin-left: 220px;color: #fff;}
        .step:nth-child(5) { height :30px; background-color: orange; margin-left: 200px;color: #fff;}
        .step:nth-child(6) { height :30px; background-color: cyan;  margin-left: 180px;color: #fff;}
        .step:nth-child(7) { height :30px; background-color: purple;  margin-left: 160px;color: #fff;}
        .step:nth-child(8) { height :30px; background-color: pink;  margin-left: 140px;color: #fff;}
        .step:nth-child(9) { height :30px; background-color: brown; margin-left: 120px;color: #fff;}
        .step:nth-child(10) { height :30px; background-color: khaki;  margin-left: 100px;color: #fff;}
        .step:nth-child(11) { height :30px; background-color: gold;  margin-left: 80px;color: #fff;}
        .step:nth-child(12) { height :30px; background-color: crimson;  margin-left: 60px;color: #fff;}
        .step:nth-child(13) { height :30px; background-color: olive;  margin-left: 40px;color: #fff;}
        .step:nth-child(14) { height :30px; background-color: olivedrab;  margin-left: 20px;color: #fff;}
    </style>
</head>

<body>
<script src="{{asset('public/main/js/jquery.min.js')}}"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="index.html">
                <img src="images/logo-dark.png" alt="" class="logo-dark" height="24" />
                <img src="images/logo-light.png" alt="" class="logo-light" height="24" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            {{-- @include('includes.main-links1') --}}
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-8">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">CORPORATE BUSINESS CONSULTANCY (CBC)</h3>
                    <p class="text-muted font-size-15 mb-4">Congratulations for graduating to this level.  </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">Congratulations for graduating to this level</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row">
           <!--This is the welcome video Presentation-->

        <!--This where the welcome presentation ends-->
            <div class="col-md-6">
                <p><b>Read the following content carefully.</b></p>
                <p>
                Your being here simply means you have successfully taken our graduation courses and you have passed the qualifying exams.
                Congratulations once again as you are now fully qualified to become a member.
                </p>
                <p>
                CBC is an organization where we utilize team efforts to create sales of products through marketing technologies.
                At CBC we train people to become marketing and business professionals and we hand them the best business marketing tools that will immediately position them in the right direction.
                We have cleared the tracks for all our members. We have done all the heavy liftings for you. We are only calling you to do nothing hard but just for you to key yourself into our already working business strategy.
                <p>

                <b>MEMBERSHIP BENEFITS</b>
                <p>
                The following are the benefits that is immediately opened to all our members worldwide:
                </P>
                <ul>
                    <li>Free monthly supplement worth of N34,000</li>
                    <li>Personal Business Software (PBS)</li>
                    <li>Sales Volume Bonus</li>
                    <li>Leadership Development Bonus</li>
                    <li>Network Development Bonus</li>
                    <li>Travelling incentives</li>
                    <li>Step up bonuses and incentives</li>
                    <li>Ongoing sales trainings</li>
                </ul>


                <b>How Does This Work?</b>

                <p>Complete our membership application form and make the payment to become a bona fide member of CBC, as one of our Business Consultants (BC). After your registration, you'll get our membership licence and begin to participate in our group monthly sales while you start qualifying for different income levels that is available to you in our organization.
                </p>
                <p>Basically, there are seven different statuses you can begin to qualify for, based on the growth of your business. The more sales you and your team generates, the bigger your payout and the higher your statuses at the end of the month.
                </p>
                <b>CBC COMPENSATION PLAN</b>

                <p>Rookie Business Consultant Level (RBC)<br/>
                As a new member you immediately qualify to receive your 100 point value for the next twelve months freely without any additional payment whatsoever. It also means you will receive a portion of our products that worth thirty four thousand naira in profit IF you sell it.
                <br/>

                With your personal business software (PBS), let's say you bring in four new members, you will step up to the next level of RBC and you will earn bonus cheque of N5000 minimum
                </p>

                <table>
                    <tr>
                        <th>No. of people</th>
                        <th>Total point</th>
                        <th>Bonus</th>
                    </tr>
                    <tr>
                        <td>You + 4 persons</th>
                        <td>500 PV</th>
                        <td>N5,000</th>
                    </tr>

                </table>
                <br/>
                <p>Every member you bring in immediately qualifies to receive a 100 point value freely for the next twelve months too just like you. So it means for the next twelve months your income will not be less than N5000 if you do not make additional sales.
                </p>
                <p>
                How To Get Four Persons to become a Rookie BUSINESS CONSULTANT (RBC)
                You don't have to go out of your house to get this done. Just tap into the unlimited contact of people you have in your what's app/ contact lists, friends & family lists etc. and send them the link to your Personal Prospecting Site (PPS) 
                </p>

                <b>NOTE:</b>
                <p>To qualify for the free monthly 100PV you, must </p>
                <ol>
                    <li>Sponsor minimum of one new member every months</li>

                    <li>Wait for one full month counting from the day of your registration</li>
                </ol>
                <br/>
                    <b>Senior Business Consultant (SBC)</b>

                    <p>Your next step is to join our SBC level where your income will increase to a whopping sum of N30,000 monthly. All you have to do here is support your team members to increase their sales to qualify as RBC. That will automatically increase your earning level.
                    <br/>
                    Since every member gets 100 pv and N34,000 worth of products every month for twelve months, you all ONLY need to focus on getting people to your team every month and that is done by utilizing your PPS/PBS judiciously.</p>
                <table>
                    <tr>
                        <th>No. of people</th>
                        <th>Total point</th>
                        <th>Bonus</th>
                    </tr>
                    <tr>
                        <td>You + 4 persons + 16 persons</th>
                        <td>2,100 PV</th>
                        <td>N40,000</th>
                    </tr>
                </table>
                <br/>
                <b>Big Business Consultant 1 (BBC 1)</b>

                <p>Since you and your team members receives free 100PV each, every month, and your only focus is to get more people in your organization, just support your people more, and your income level will increase. Here, you support your team members to step up to the level of SBC and your status changes.
                <p>

                <table>
                    <tr>
                        <th>No. of people</th>
                        <th>Total point</th>
                        <th>Bonus</th>
                    </tr>
                    <tr>
                        <td>You + 4 persons + 16 persons + 64 persons</th>
                        <td>8,500 PV</th>
                        <td>N150,000</th>
                    </tr>
                </table>
                <br/>
                <p>When you qualify as one of our BBC1, you will begin to experience huge positive changes in your life and you have also qualified to start stepping up to higher statuses with higher earning benefits as you focus and build your business bigger and wider.
                    The following are the different levels of statuses you can now start focusing on….
                </p>

                <div id='stepContainer'>
                    <div class='step'>SEBC</div>
                    <div class='step'>EBC 6</div>
                    <div class='step'>EBC 5</div>
                    <div class='step'>EBC 4</div>
                    <div class='step'>EBC 3</div>
                    <div class='step'>EBC 2</div>
                    <div class='step'>EBC 1</div>
                    <div class='step'>PBC 3</div>
                    <div class='step'>PBC 2</div>
                    <div class='step'>PBC 1</div>
                    <div class='step'>BBC 2</div>
                    <div class='step'>BBC 1</div>
                    <div class='step'>SBC </div>
                    <div class='step'>RBC</div>
                </div>
                <br/>
                <table>
<tbody>
<tr>
<td width="300">
<p>Level</p>
</td>
<td width="300">
<p>Total Point</p>
</td>
<td width="300">
<p>Monthly Bonus</p>
</td>
</tr>
<tr>
<td width="300">
<p>RBC</p>
</td>
<td width="300">
<p>500PV</p>
</td>
<td width="300">
<p>N5000</p>
</td>
</tr>
<tr>
<td width="300">
<p>SBC</p>
</td>
<td width="300">
<p>1000PV</p>
</td>
<td width="300">
<p>N30,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>BBC 1</p>
</td>
<td width="300">
<p>4000PV</p>
</td>
<td width="300">
<p>N100,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>BBC 2</p>
</td>
<td width="300">
<p>4000PV</p>
</td>
<td width="300">
<p>N100,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>PBC 1</p>
</td>
<td width="300">
<p>10,000PV</p>
</td>
<td width="300">
<p>N200,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>PBC 2</p>
</td>
<td width="300">
<p>20,000PV</p>
</td>
<td width="300">
<p>N300,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>PBC 3</p>
</td>
<td width="300">
<p>30,000PV</p>
</td>
<td width="300">
<p>N400,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>PBC 4</p>
</td>
<td width="300">
<p>50,000PV</p>
</td>
<td width="300">
<p>N500,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>EBC 1</p>
</td>
<td width="300">
<p>100,000PV</p>
</td>
<td width="300">
<p>N1,000,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>EBC 2</p>
</td>
<td width="300">
<p>150,000PV</p>
</td>
<td width="300">
<p>N1,500,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>EBC 3</p>
</td>
<td width="300">
<p>200,000PV</p>
</td>
<td width="300">
<p>N2,000,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>EBC 4</p>
</td>
<td width="300">
<p>250,000PV</p>
</td>
<td width="300">
<p>N2,500,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>EBC 5</p>
</td>
<td width="300">
<p>300,000PV</p>
</td>
<td width="300">
<p>N3,000,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>EBC 6</p>
</td>
<td width="300">
<p>400,000PV</p>
</td>
<td width="300">
<p>N3,500,000</p>
</td>
</tr>
<tr>
<td width="300">
<p>SEBC</p>
</td>
<td width="300">
<p>500,000PV</p>
</td>
<td width="300">
<p>N5,000,000</p>
</td>
</tr>
</tbody>
</table>
<br/>
<p><strong>Definitions and Terminologies</strong></p>
<p>PV- Point Value: (The point that is attached to each products)</p>
<p>RBC -Rookie Business Consultant Level</p>
<p>SBC -Senior Business Consultant Level</p>
<p>BBC -Big Business Consultant Level</p>
<p>PBC -Pro Business Consultant Level</p>
<p>EBC -Executive Business Consultant Level</p>
<p>SEBC -Special Executive Business Consultant Level</p>
<p>PPS -Personal Prospecting Software</p>
<p>PBS -Personal Business Software</p>
<p>Bonus -Monthly income (It is calculated base on the bonus volume that is attached to each products)</p>
                <div class="col-sm-12" style="display: inline-block;">
                    <p style="color: green">Now you can proceed to complete your registration to become our member</p>
                    <a href="{{url('visitors/profile/')}}" class="btn btn-primary pull-right" style="float: right;">Proceed >></a>
                </div>

            </div>
            <div class="col-md-5">
                <div class="mb-4 mb-lg-0">
                    <img src="{{asset('public/main/images/features-img.png')}}" alt="" class="img-fluid d-block mx-auto">
                <video width="100%" height="auto" controls>
                    <source src="{{asset('public/main/videos/video1.mp4')}}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
                </div>
            </div>
        </div>
        
    </div>
</section>
<!-- Features End -->


    @include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>