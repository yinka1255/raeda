<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | About us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
</head>

<body>
<script src="https://js.paystack.co/v1/inline.js"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="index.html">
                <img src="images/logo-dark.png" alt="" class="logo-dark" height="24" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            @include('includes.main-links1')
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-9">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    @if($subscription == null)
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">Welldone. This is the final stage to become our member.</h3>
                    <p class="text-muted font-size-15 mb-4">Pay a one time fee of N58,250 to qualify for 12 months free wellness product with value of N30,000. </p>
                    @else
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">Congratulations!.</h3>
                    <p class="text-muted font-size-15 mb-4">You are now a member and you have qualified for 12 months free wellness product with value of N30,000. Kindly go through the below video to understand the benefit that awaits you. </p>
                    @endif
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">Profile</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row ">
            <div class="col-lg-7 ">
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('sub_success'))
                    <p style="color: green">{{Session::get('sub_success')}}</p>
                    @elseif(Session::has('sub_error'))
                    <p style="color: red">{{Session::get('sub_error')}}</p>
                    @endif
                </div>
            </div>
            @if($subscription == null)
            @foreach($plans as $plan)
            @if($plan->id == 6)
            <button type="button" onclick='payWithPaystack("{{$plan->amount}}", "{{$plan->name}}", "{{$plan->id}}")' class="btn btn-primary" style="margin-bottom: 30px;">Subsccribe {{$plan->amount}} (one time fee)</button>
            @endif
            @endforeach
            {{--
            <button type="button" onclick="payWithPaystack()" class="btn btn-primary" style="margin-bottom: 30px;">Pay one time fee now to become a member (N58,250)</button>
            --}}
            @endif
            
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('success'))
                    <p style="color: green">{{Session::get('success')}}</p>
                    @elseif(Session::has('error'))
                    <p style="color: red">{{Session::get('error')}}</p>
                    @endif
                </div>
            </div>
                <form method="post" action="{{url('visitors/update_profile')}}"  >
                {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">First name</label>
                                <input type="text" name="first_name" id="first_name" class="form-control" value="{{$loggedInUser->first_name}}" placeholder="Your first name..." required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Last name</label>
                                <input type="text" name="last_name" id="last_name" class="form-control" value="{{$loggedInUser->last_name}}" placeholder="Your last name..." required>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="name">Partner's Fullname*</label>
                                <input name="partner_name" id="partner_name" type="text" class="form-control" value="{{$loggedInUser->partner_name}}" placeholder="Your partner's fullname...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="phone">Phone*</label>
                                <input name="phone" id="phone" class="form-control" value="{{$loggedInUser->phone}}" required placeholder="Your phone...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="partnerphone">Partner's Phone*</label>
                                <input name="partner_phone" id="partner_phone" class="form-control" value="{{$loggedInUser->partner_phone}}" required placeholder="Your partner's phone...">
                            </div>
                        </div>
                        {{--
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="passport_no">Passport no*</label>
                                <input name="passport_no" id="passport_no" class="form-control" value="{{$loggedInUser->passport_no}}" required placeholder="Your passport no...">
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="partner_passport_no">Partner's Passport no*</label>
                                <input name="partner_passport_no" id="partner_passport_no" class="form-control" value="{{$loggedInUser->partner_passport_no}}" required placeholder="Your partner's passport no...">
                            </div>
                        </div>
                        --}}
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="address">Address*</label>
                                <input name="address" id="address" class="form-control" value="{{$loggedInUser->address}}" required placeholder="Your address...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Email Address*</label>
                                <input name="email" id="email" type="email" class="form-control" value="{{$loggedInUser->email}}" readonly placeholder="Your email...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="message">Date of birth*</label>
                                <input name="dob" class="form-control" value="{{$loggedInUser->dob}}" id="datepicker" >
                                </textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="banks">Bank</label>
                                <select class="form-control" name="bank">
                                    <option value="access">Access Bank</option>
                                    <option value="citibank">Citibank</option>
                                    <option value="diamond">Diamond Bank</option>
                                    <option value="ecobank">Ecobank</option>
                                    <option value="fidelity">Fidelity Bank</option>
                                    <option value="first bank">First Bank </option>
                                    <option value="fcmb">First City Monument Bank (FCMB)</option>
                                    <option value="fsdh">FSDH Merchant Bank</option>
                                    <option value="gtb">Guarantee Trust Bank (GTB)</option>
                                    <option value="heritage">Heritage Bank</option>
                                    <option value="Keystone">Keystone Bank</option>
                                    <option value="rand">Rand Merchant Bank</option>
                                    <option value="skye">Skye Bank</option>
                                    <option value="stanbic">Stanbic IBTC Bank</option>
                                    <option value="standard">Standard Chartered Bank</option>
                                    <option value="sterling">Sterling Bank</option>
                                    <option value="suntrust">Suntrust Bank</option>
                                    <option value="union">Union Bank</option>
                                    <option value="uba">United Bank for Africa (UBA)</option>
                                    <option value="unity">Unity Bank</option>
                                    <option value="wema">Wema Bank</option>
                                    <option value="zenith">Zenith Bank</option>
                                </select>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="address">Bank Account holder's name.</label>
                                <input name="bank_account_name" class="form-control" value="{{$loggedInUser->bank_account_name}}" required placeholder="Your bank account holder's name...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="address">Account no.</label>
                                <input name="bank_account_number" type="number" class="form-control" value="{{$loggedInUser->bank_account_number}}" required placeholder="Your bank account number...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="banks">Account type</label>
                                <select class="form-control" name="bank_account_type" required>
                                    <option value="Savings">Savings</option>
                                    <option value="Current">Current</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="address">Branch code</label>
                                <input name="branch_code" class="form-control" value="{{$loggedInUser->branch_code}}" required placeholder="Your bank branch code...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="address">Branch name</label>
                                <input name="branch_name" class="form-control" value="{{$loggedInUser->branch_name}}" required placeholder="Your branch...">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary">Update profile <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                            <div id="simple-msg"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-1">
            </div>

        </div>
        <div class="row align-items-center" style="margin-top: 40px;">
        
            <div class="col-lg-7 ">
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('success'))
                    <p style="color: green">{{Session::get('success')}}</p>
                    @elseif(Session::has('error'))
                    <p style="color: red">{{Session::get('error')}}</p>
                    @endif
                </div>
            </div>
                <form method="post" action="{{url('visitors/update_password')}}" >
                {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="name">Password</label>
                                <input name="password" id="password" type="password" class="form-control" placeholder="********">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="name">Confirm Password</label>
                                <input name="cpassword" id="cpassword" type="password" class="form-control" placeholder="********">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="submit" id="submit" name="send" class="btn btn-primary">Update password <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<form method="post" style="display: none;" id="paymentForm" action="{{url('visitors/subscribe')}}" >
                {{ csrf_field() }}
    <input name="transaction_ref" id="transaction_ref" class="form-control" >
    <input name="amount" id="amount" class="form-control" >
    <input name="plan_id" id="plan_id" class="form-control" >
</form>              

<!-- Features End -->
<form>
  <script>
    function payWithPaystack(amount, plan, plan_id){
        if(document.getElementById('first_name').value == ""  || document.getElementById('last_name').value == ""){
            alert("Kindly fill in all your details first");
            return;
        }
      
    var handler = PaystackPop.setup({
      key: "pk_live_9015c878da056c913db314713eb4e7872f814c33",
      email: document.getElementById('email').value,
      amount: amount* 100,
      ref: {{time()}},
      currency: "NGN",
      metadata: {
        custom_fields: [
        { display_name: "Full Names", variable_name: "full_names", value: document.getElementById('first_name').value + ' ' + document.getElementById('last_name').value },
        { display_name: "Email Address", variable_name: "email_address", value: document.getElementById('email').value },
        { display_name: "Phone", variable_name: "phone", value: document.getElementById('phone').value },
        
        ]
      },
      callback: function(response){
        alert('Payment was success. transaction ref is ' + response.reference);
        $("#transaction_ref").val(response.reference);
        $("#plan_id").val(plan_id);
        var am = amount
        $("#amount").val(am);
        document.getElementById("paymentForm").submit();
        
      },
      onClose: function(){
        alert('Transaction Cancelled');
        
      }
    });
    handler.openIframe();
    }
  </script>
</form>

    @include('includes.footer')
    @include('includes.main-scripts')
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
</body>
</html>