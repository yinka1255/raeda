<!DOCTYPE html>
<html lang="en" style="height: 100% !important;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Visitor's Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    <!-- favicon -->
    @include('includes.main-css')
</head>

<body style="height: 100% !important;">
<script src="{{asset('public/main/js/jquery.min.js')}}"></script>

    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

        <!--Navbar Start-->
        <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
            <div class="container">
                <!-- LOGO -->
                <a class="navbar-brand logo" href="index.html">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                    <img src="{{asset('public/main/images/logo-light.png')}}" alt="" class="logo-light" height="45" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                {{-- @include('includes.main-links1') --}}
                </div>
            </div>
        </nav>
        <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/hero-2-bg.jpg')}}); height: 100%">
        <div class="container"style="margin-top: 120px;">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                     <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">Your sure path to become a successful enterpreneur</b>.</h3>
                    <!-- <h3 class="font-weight-semibold line-height-1_4 mb-4">Build <b>community</b> & <b>conversion</b> with our suite of <b>social tool</b></h3> -->
                    <p class="text-white font-size-15 mb-4">You are about to become a professional Business Consultant (BC) and start earning gradually to become a millionaire. But first, you need to learn how to think like an entrepreneur and experience an awesome paradigm shift, because financial success happens first in your mental space and then in your physical space. Gain access to our academic space and become a business expert</p>
                    <!--<p class="text-white mb-2"> If you haven't register yet, click register or call us on  +234 (813) 0973748 to get onboarded</p>-->
                    <div class="mt-5">
                        <a href="#" class="btn btn-primary mr-2">Get Started</a>
                    </div>
                </div>
        <!-- Login Modal -->
                <!-- <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden=""> -->
                    <div class="modal-dialog col-lg-5" style="margin-top: 70px;">
                        <div class="modal-content ">
                            <div class="modal-body">
                                <div class="text-center">
                                    <!--<h3 class="title mb-4">Welcome To TeamRondo</h3>-->
                                    <p style="font-size: 18px;" class="text-uppercase text-primary"><b>Register</b></p>
                                </div>
                                <div class="login-form mt-4">
                                @if(Session::has('success'))
                                <p style="color: green">{{Session::get('success')}}</p>
                                @elseif(Session::has('error'))
                                <p style="color: red">{{Session::get('error')}}</p>
                                @endif
                                <form method="post" role="form" action="{{url('visitors/create')}}">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="id_number" class="form-control" value="{{$id_number}}">
                                        {{-- 
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Fullname</label>
                                            <input type="text" name="name" class="form-control" placeholder="Your name..." required>
                                        </div>
                                        --}}
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">First name</label>
                                            <input type="text" name="first_name" class="form-control" placeholder="Your first name..." required>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Last name</label>
                                            <input type="text" name="last_name" class="form-control" placeholder="Your last name..." required>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Phone</label>
                                            <input type="text" name="phone" class="form-control" placeholder="Your phone..." required>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Full address</label>
                                            <input type="text" name="address" class="form-control" placeholder="Your full address..." required>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Email</label>
                                            <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Youremail@gmail.com" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                                            <label class="custom-control-label font-size-15" for="customCheck1">Remember Me</label>
                                        </div>
                                        <div class="text-center mt-4">
                                            <button type="submit" class="btn btn-primary">Register <i class="icon-size-15 icon ml-1" data-feather="arrow-right-circle"></i></button>
                                        </div>
                                    </form>
                                    
                                    <div class="text-center">
                                        
                                        <p class="mb-0">Have an account? <a href="{{url('visitors/login/'.$id_number)}}" class="text-primary">Login</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                       <!-- End of login Modal -->
                <!-- <div class="col-lg-6 offset-lg-1">
                    <div class="mt-4 mt-lg-0">
                        <img src="images/features-img-1.png" alt="" class="img-fluid d-block mx-auto">
                    </div>
                </div> -->
            </div>
        </div>
    </section>
    <!-- Hero End -->
	@include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>