<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | About us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    
</head>

<body>

    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="{{url('/')}}">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            @include('includes.main-links')
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="hero-2-bg" style="background-image: url({{asset('public/main/images/hero-2-bg.jpg')}}); height: 600px; padding-top: 123px !important;"; id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 0px;">
                <div class="col-lg-5">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">We do the work you <b>stay focused</b> on <b>your customers</b>.</h3>
                    <!-- <h3 class="font-weight-semibold line-height-1_4 mb-4">Build <b>community</b> & <b>conversion</b> with our suite of <b>social tool</b></h3> -->
                    <p class="text-muted font-size-15 mb-4">Temporibus autem quibusdam et aut officiis debitis aut rerum a necessitatibus saepe eveniet ut et voluptates repudiandae sint molestiae non recusandae itaque.</p>
                    <p class="text-muted mb-2"><i class="icon-xs mr-1" data-feather="server"></i> Donec pede justo fringilla vel nec.</p>
                    <p class="text-muted"><i class="icon-xs mr-1" data-feather="rss"></i> Cras ultricies mi eu turpis hendrerit fringilla.</p>
                    <div class="mt-5">
                        <a href="#" class="btn btn-primary mr-2">Read More</a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">About Us</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row align-items-center">
            
            <div class="col-lg-7 ">
                <!-- <p class="font-weight-medium text-uppercase mb-2"><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> Creative Features</p> -->
                <h3 class="font-weight-semibold line-height-1_4 mb-4 h4">TeamRondo solution's <b>mission</b></h3>
                <p class="font-size-15  mb-4">TeamRondo Solution is a subsidiary of Rapid And Pragmatic Millions Enterprise setup to provide state of the earth marketing and business solution to Team Rondo Dynasty and the entire Neo life family at large.</p>
                <p class="font-size-15  mb-4">TeamRondo solution’s mission is to enable existing, and wanna be business consultant in Team Rondo Dynasty and the entire Neo Life family to grow their MLM business professionally, and achieve their goals — quickly and easily. </p>
                <p class=" mb-2"><i class="icon-xs mr-1" data-feather="layout"></i> Donec pede justo fringilla vel nec.</p>
                <p class="text-muted"><i class="icon-xs mr-1" data-feather="life-buoy"></i> Cras ultricies mi eu turpis hendrerit fringilla.</p>
            </div>
            <div class="col-lg-5">
                <div class="mb-4 mb-lg-0">
                    <img src="{{asset('public/main/images/features-img.png')}}" alt="" class="img-fluid d-block mx-auto">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Features End -->

    <!-- Features Start -->
    <section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
        <div class="container">
            <div class="row ">
                <div class="col-lg-12">
                    
                    <div class=" mb-5">
                        <h3 class="h4 mb-3">Building Network Marketing Business Shouldn’t be So difficult. </h3>
                        <p class=" font-size-15">Network Marketing is no doubt THE ONLY business opportunity that is extremely certain to change anyone’s life for better.. 
                            This means that every network marketers are the real life changers-Then nobody deserves respect better than network marketers.  
                            The leader of Team Rondo Dynasty and one of the successors of the great Rondo is Remi Adepoju, has dedicated a very huge part of his life researching the best way to re-position network marketers in the minds of the public and to professionally take his father’s legacy to the greatest height ever seen. With the collaborative efforts of his siblings and his mum, he has come up with a wonderful solution called “Teamrondo solution” 
                            What's the problem? </p>
                           <p>Succeeding and making it big in network marketing has become so hard. People dread the business so much that it makes them want to fall sick just at the mention of the word “Network Marketing”​	and this makes people miss out the juicy parts of being part of the Neo Life's family​.
                            The only known reason to that stigma is evidently “the lack of good marketing system” which has ridiculed network marketers to the system of Roaming ​	​the street in search of anyone and everyone that care to listen to their sales pitch. 
                            Teamrondo Solution has salvaged that challenges both for the TeamRondo Dynasty and the entire Neo Life family. The TeamRondo Solution prospecting software has been professionally designed with every networkers in mind. 
                            Now, Networkers do not need to brake a single sweat trying to find prospect for their business. The leader has made sure all his team members can now have more prospect than they can handle using the Teamrondo Solution Prospecting tool</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @include('includes.footer')
    @include('includes.main-scripts')
</body>
</html>