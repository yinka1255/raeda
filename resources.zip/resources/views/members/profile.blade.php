<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
</head>

<body>
<script src="https://js.paystack.co/v1/inline.js"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="{{url('/')}}">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            @include('includes.main-links')
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-5">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">We do the work you <b>stay focused</b> on <b>sales team for step ups</b>.</h3>
                    <p class="text-muted font-size-15 mb-4"> </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">Profile</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row ">
            <div class="col-lg-7 ">
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('sub_success'))
                    <p style="color: green">{{Session::get('sub_success')}}</p>
                    @elseif(Session::has('sub_error'))
                    <p style="color: red">{{Session::get('sub_error')}}</p>
                    @endif
                </div>
            </div>
            @if($subscription == null)
            <p style="color: red;"><i class="fa fa-cancel"></i> You do not have any valid subscription</p>
            @foreach($plans as $plan)
            @if($plan->id == 1)
            <button type="button" onclick='payWithPaystack("{{$plan->amount}}", "{{$plan->name}}", "{{$plan->id}}")' class="btn btn-primary" style="margin-bottom: 30px;">Subsccribe {{$plan->amount}} for {{($plan->days)/30}} months</button>
            @endif
            @endforeach
            {{--
            <button type="button" onclick="payWithPaystack('200000', 'First subscription')" class="btn btn-primary" style="margin-bottom: 30px;">Subsccribe now (N2,000)</button>
            --}
            @elseif($subscription->expiry_date > now())
            <p style="color: green;"><i class="fa fa-times"></i> Your subscripion is active and will expire on {{$subscription->expiry_date}}</p>
            @elseif($active_subscription == null)
            
            
            <p style="color: red;"><i class="fa fa-cancel"></i> Your do not have any active subscription.</p>
            @foreach($plans as $plan)
            @if($plan->id != 1 && $plan->id != 6)
            <button type="button" onclick='payWithPaystack("{{$plan->amount}}", "{{$plan->name}}", "{{$plan->id}}")' class="btn btn-primary" style="margin-bottom: 30px;">Subsccribe {{$plan->amount}} for {{($plan->days)/30}} months</button>
            @endif
            @endforeach
            {{--
            <button type="button" onclick="payWithPaystack('150000', 'Subsequent subscription')" class="btn btn-primary" style="margin-bottom: 30px;">Subsccribe (N1,500) for 1 month</button>
            <button type="button" onclick="payWithPaystack('390000', 'Subsequent subscription')" class="btn btn-warning" style="margin-bottom: 30px;">Subsccribe (N3,900) for 3 month</button>
            <button type="button" onclick="payWithPaystack('660000', 'Subsequent subscription')" class="btn btn-danger" style="margin-bottom: 30px;">Subsccribe (N6,600) for 6 month</button>
            <button type="button" onclick="payWithPaystack('900000', 'Subsequent subscription')" class="btn btn-success" style="margin-bottom: 30px;">Subsccribe (N9,000) for 12 month</button>
            --}}
            @elseif($active_subscription->expiry_date > now())
            <p style="color: green;"><i class="fa fa-times"></i> Your subscripion is active and will expire on {{$subscription->expiry_date}}</p>
            
            @endif
           
            
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('success'))
                    <p style="color: green">{{Session::get('success')}}</p>
                    @elseif(Session::has('error'))
                    <p style="color: red">{{Session::get('error')}}</p>
                    @endif
                </div>
            </div>
                <form method="post" action="{{url('members/update_profile')}}"  >
                {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Link</label>
                                <input name="link" type="text" class="form-control" readonly value="https://www.teamrondo.com/member/{{$loggedInUser->id_number}}">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">First name</label>
                                <input type="text" id="first_name" name="first_name" value="{{$loggedInUser->first_name}}" class="form-control" placeholder="Your first name..." required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Last name</label>
                                <input type="text" id="last_name" name="last_name" value="{{$loggedInUser->last_name}}" class="form-control" placeholder="Your last name..." required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Phone*</label>
                                <input name="phone" id="phone" class="form-control" value="{{$loggedInUser->phone}}" required placeholder="Your phone...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Email Address*</label>
                                <input name="email" id="email" type="email" class="form-control" value="{{$loggedInUser->email}}" readonly placeholder="Your email...">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="message">Date of birth*</label>
                                <input name="dob" class="form-control" value="{{$loggedInUser->dob}}" id="datepicker" >
                                </textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Team ID*</label>
                                <input name="team_id" type="text" class="form-control" readonly value="{{$loggedInUser->team_id}}">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">ID number*</label>
                                <input name="id_number" type="text" class="form-control" readonly value="{{$loggedInUser->id_number}}">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary">Update profile <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                            <div id="simple-msg"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-2">
            </div>
            {{--
            <div class="col-lg-3">
                <div class="pull-right">
                    <p style="font-size: 16px;"><b>Members' links</b></p>
                <ul class="">
                    <li class="mr-4"><a href="{{url('members/profile')}}" >Profile</a></li>
                    <li class="mr-4"><a href="{{url('members/visitors')}}" >Visitors</a></li>
                    <li class="mr-4"><a href="{{url('members/appointments')}}" >Appointments</a></li>
                    <li class="mr-4"><a href="{{url('members/broadcasts')}}" >Broadcasts</a></li>
                </ul>
                </div>
            </div>
            --}}
        </div>
        <div class="row align-items-center" style="margin-top: 40px;">
        
            <div class="col-lg-7 ">
            <div class="row">
                <div class="col-md-12">
                    @if(Session::has('success'))
                    <p style="color: green">{{Session::get('success')}}</p>
                    @elseif(Session::has('error'))
                    <p style="color: red">{{Session::get('error')}}</p>
                    @endif
                </div>
            </div>
                <form method="post" action="{{url('members/update_password')}}" >
                {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="name">Password</label>
                                <input name="password" id="password" type="password" class="form-control" placeholder="********">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="name">Confirm Password</label>
                                <input name="cpassword" id="cpassword" type="password" class="form-control" placeholder="********">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="submit" id="submit" name="send" class="btn btn-primary">Update password <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Features End -->

<form method="post" style="display: none;" id="paymentForm" action="{{url('members/subscribe')}}" >
                {{ csrf_field() }}
    <input name="transaction_ref" id="transaction_ref" class="form-control" >
    <input name="amount" id="amount" class="form-control" >
    <input name="plan_id" id="plan_id" class="form-control" >
</form>

<form>
  <script>
    function payWithPaystack(amount, plan, plan_id){
      
    var handler = PaystackPop.setup({
      key: "pk_live_9015c878da056c913db314713eb4e7872f814c33",
      email: document.getElementById('email').value,
      amount: amount*100,
      ref: {{time()}},
      currency: "NGN",
      metadata: {
        custom_fields: [
        { display_name: "Full Names", variable_name: "full_names", value: document.getElementById('first_name').value },
        { display_name: "Email Address", variable_name: "email_address", value: document.getElementById('email').value },
        { display_name: "Phone", variable_name: "phone", value: document.getElementById('phone').value },
        
        ]
      },
      callback: function(response){
        alert('Payment was success. transaction ref is ' + response.reference);
        $("#transaction_ref").val(response.reference);
        $("#plan_id").val(plan_id);
        var am = amount
        $("#amount").val(am);
        document.getElementById("paymentForm").submit();
        
      },
      onClose: function(){
        alert('Transaction Cancelled');
        
      }
    });
    handler.openIframe();
    }
  </script>
</form>
    @include('includes.footer')
    @include('includes.main-scripts')
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
</body>
</html>