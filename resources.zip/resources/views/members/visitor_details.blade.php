<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Visitors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    
</head>

<body>
    <?php 
function months($date1, $date2)
{
    
$ts1 = strtotime($date1);
$ts2 = strtotime($date2);

$year1 = date('Y', $ts1);
$year2 = date('Y', $ts2);

$month1 = date('m', $ts1);
$month2 = date('m', $ts2);

$diff = (($year2 - $year1) * 12) + ($month2 - $month1);

    return $diff;
}
?>
<script src="https://js.paystack.co/v1/inline.js"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="{{url('/')}}">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            @include('includes.main-links')
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-9">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">We do the work you <b>stay focused</b> on <b>sales team for step ups</b>.</h3>
                    <p class="text-muted font-size-15 mb-4"> </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">Your member details</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
        <div class="row">
			<div class="col-md-6">
				<table style="width: 100%;" border="1px" style="margin-bottom: 20px;">
					<tr>
						<td class="grey">
							First name
						</td>
						@if($visitor->first_name !== null || $visitor->first_name != "")
						<td class="light">
								{{$visitor->first_name}} 
						</td>
						@else
						<td class="light">
								NO FIRST NAME PROVIDED
						</td>
						@endif
					</tr>
					<tr>
					    <td class="grey">
							Last name
						</td>
						@if($visitor->last_name !== null || $visitor->last_name != "")
						<td class="light">
								{{$visitor->last_name}}
						</td>
						@else
						<td class="light">
								NO LAST NAME PROVIDED
						</td>
						@endif
					</tr>
					<tr>
						<td class="grey">
							Phone
						</td>
							@if($visitor->phone != null || $visitor->phone != "")
						<td class="light">
								{{$visitor->phone}} 
						</td>
						@else
						<td class="light">
								NO PHONE PROVIDED
						</td>
						@endif
					</tr>
					<tr>
						<td class="grey">
							Address
						</td>
							@if($visitor->address != null || $visitor->address != "")
						<td class="light">
								{{$visitor->address}}
						</td>
						@else
						<td class="light">
								NO ADDRESS PROVIDED
						</td>
						@endif
					</tr>
					<tr>
						<td class="grey">
							Email
						</td>
							@if($visitor->email != null || $visitor->email != "")
						<td class="light">
								{{$visitor->email}} 
						</td>
						@else
						<td class="light">
								NO EMAIL PROVIDED
						</td>
						@endif
					</tr>
					<tr>
						<td class="grey">
							Date of birth
						</td>
						<td class="light">
								{{$visitor->dob}} 
						</td>
					</tr>
					<tr>
						<td class="grey">
							Team ID
						</td>
						<td class="light">
								{{$visitor->team_id}} 
						</td>
					</tr>
					<tr>
						<td class="grey">
							Lead ID number
						</td>
						<td class="light">
								{{$visitor->id_number}} 
						</td>
					</tr>
					<tr>
						<td class="grey">
							Team Lead
						</td>
						<td class="light">
								{{$visitor->member_first_name}} {{$visitor->member_last_name}} 
						</td>
					</tr>
					<tr>
						<td class="grey">
							Partner 
						</td>
						<td class="light">
								{{$visitor->partner_name}} 
						</td>
						
					</tr>
					<tr>
						<td class="grey">
							Partner's phone 
						</td>
						<td class="light">
								{{$visitor->partner_phone}}
						</td>
						
					</tr>
					<tr>
						<td class="grey">
							Countdown
						</td>
							@if(count($subscriptions) > 0)
						<td class="light">
								<?php echo months($subscriptions[0]->created_at, date("Y-m-d")); ?> month
						</td>
						@else
						<td class="light">
								NO SUBSCRIPTION YET
						</td>
						@endif
					</tr>
				</table>
			</div>
			<div class="col-md-6">
			    <h3>Add note</h3>
			    <div class="row">
                    <div class="col-md-12">
                        @if(Session::has('success'))
                        <p style="color: green">{{Session::get('success')}}</p>
                        @elseif(Session::has('error'))
                        <p style="color: red">{{Session::get('error')}}</p>
                        @endif
                    </div>
                </div>
			     <form method="post" action="{{url('members/add_note')}}"  >
                {{ csrf_field() }}
                <input type="hidden" name="visitor_id" value="{{$visitor->id}}" />
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Note</label>
                                <textarea name="body"  class="form-control" > </textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary">Add note <i class="icon-size-15 ml-2 icon" data-feather="send"></i></button>
                            <div id="simple-msg"></div>
                        </div>
                    </div>
                </form>
			 </div>
		</div>
       <div class="row " style="margin-top: 20px;">
            <div class="col-lg-7 ">
                
                <table class="table table-bordered datatable" id="table-1">
					<thead>
						<tr>
							<th>S/N</th>
							<th>Comment</th>
                            <th>Created</th>
						</tr>
					</thead>
					<tbody>
						@foreach($notes as $key=>$note)
						<tr class="odd gradeX">
							<td>{{$key + 1}}</td>
							<td>{{$note->body}}</td>
                            <td>{{ $note->created_at }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="col-lg-2">
            </div>
            {{--
            <div class="col-lg-3">
                <div class="pull-right">
                    <p style="font-size: 16px;"><b>Members' links</b></p>
                <ul class="">
                    <li class="mr-4"><a href="{{url('members/profile')}}" >Profile</a></li>
                    <li class="mr-4"><a href="{{url('members/visitors')}}" >Visitors</a></li>
                    <li class="mr-4"><a href="{{url('members/appointments')}}" >Appointments</a></li>
                    <li class="mr-4"><a href="{{url('members/broadcasts')}}" >Broadcasts</a></li>
                </ul>
                </div>
            </div>
            --}}
        </div>
    </div>
</section>
<!-- Features End -->

<link rel="stylesheet" href="{{asset('public/admin/js/datatables/datatables.css')}}">
<script src="{{asset('public/admin/js/datatables/datatables.js')}}"></script>
<script type="text/javascript">
    jQuery( document ).ready( function( $ ) {
        var $table1 = jQuery( '#table-1' );
        
        // Initialize DataTable
        $table1.DataTable( {
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "bStateSave": true
        });
        
        
    } );
</script>
@include('includes.footer')
@include('includes.main-scripts')
</body>
</html>