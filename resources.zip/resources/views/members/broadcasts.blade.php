<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden;">

<head>
    <meta charset="utf-8" />
    <title>Rondo | Broadcasts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    @include('includes.main-css')
    <link rel="stylesheet" href="{{ asset('public/main/calendar/css/calendar.css')}}">
</head>

<body>
<script src="https://js.paystack.co/v1/inline.js"></script>
    <!-- Loader -->
    <!--
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    -->

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="{{url('/')}}">
                    <img src="{{asset('public/main/images/logo-dark.png')}}" alt="" class="logo-dark" height="45" />
                </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            @include('includes.main-links')
                
            </div>
        </div>
    </nav>
    

        
        <!-- Hero Start -->
    <section class="" style="background-image: url({{asset('public/main/images/about.jpg')}});padding-top: 0 !important;height: 250px;background-position: center;
          background-repeat: no-repeat;
          background-size: cover; " id="home">
        <div class="container">
            <div class="row align-items-center" style="padding-top: 45px;">
                <div class="col-lg-9">
                    <p class="font-weight-medium text-uppercase mb-2 "><i class="mdi mdi-chart-bubble h2 text-primary mr-1 align-middle"></i> </p>
                    <h3 class="font-weight-bold text-white line-height-2_4 mb-4 h2">We do the work you <b>stay focused</b> on <b>sales team for step ups</b>.</h3>
                    <p class="text-muted font-size-15 mb-4"> </p>
                    
                </div>
                
            </div>
        </div>
    </section>
    <!-- Hero End -->

        <p class="row align-items-center justify-content-center line-height-1_4 h4 " style="margin-top: 40px;">Your broadcast</p>

<!-- Features Start -->
<section class="section bg-light feather-bg-img" style="background-image: url({{asset('public/main/images/features-bg-img.png')}});" id="features">
    <div class="container">
       <div class="row ">
            <div class="col-lg-9 ">
                <div class="row">
                    <div class="col-md-12">
                        @if(Session::has('success'))
                        <p style="color: green">{{Session::get('success')}}</p>
                        @elseif(Session::has('error'))
                        <p style="color: red">{{Session::get('error')}}</p>
                        @endif
                    </div>
                </div>
                <a href="{{ url('members/new_broadcast') }}" style="float: right; margin-bottom: 20px;" class="btn btn-primary">New broadcast message</a>
                <table class="table table-bordered datatable" id="table-1">
					<thead>
						<tr>
							<th>S/N</th>
							<th>Visitor's name</th>
							<th>Visitor's email</th>
							<th>Visitor's phone</th>
							<th>Title</th>
                            <th>Message</th>
                            <th>Created</th>
						</tr>
					</thead>
					<tbody>
						@foreach($broadcasts as $key=>$broadcast)
						<tr class="odd gradeX">
							<td>{{$key + 1}}</td>
                            @if($broadcast->visitor_first_name != null)
							<td>{{$broadcast->visitor_first_name}} {{$broadcast->visitor_last_name}}</td>
                            @else
                            <td>All</td>
                            @endif
                            @if($broadcast->visitor_email != null)
                            <td>{{$broadcast->visitor_email}}</td>
                             @else
                            <td></td>
                            @endif
                            @if($broadcast->visitor_phone)
                            <td>{{$broadcast->visitor_phone}}</td>
                            @else
                            <td></td>
                            @endif
                            <td>{{$broadcast->title}}</td>
                            <td>{{ $broadcast->message }}</td>
                            <td>{{ date('d-m-Y', strtotime($broadcast->created_at)) }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{--
            <div class="col-lg-3">
                <div class="pull-right">
                    <p style="font-size: 16px;"><b>Members' links</b></p>
                <ul class="">
                    <li class="mr-4"><a href="{{url('members/profile')}}" >Profile</a></li>
                    <li class="mr-4"><a href="{{url('members/visitors')}}" >Visitors</a></li>
                    <li class="mr-4"><a href="{{url('members/broadcasts')}}" >Appointments</a></li>
                    <li class="mr-4"><a href="{{url('members/broadcasts')}}" >Broadcasts</a></li>
                </ul>
                </div>
            </div>
            --}}
        </div>
    </div>
</section>
<!-- Features End -->


@include('includes.footer')
@include('includes.main-scripts')

<link rel="stylesheet" href="{{asset('public/admin/js/datatables/datatables.css')}}">
<script src="{{asset('public/admin/js/datatables/datatables.js')}}"></script>
<script type="text/javascript">
    jQuery( document ).ready( function( $ ) {
        var $table1 = jQuery( '#table-1' );
        
        // Initialize DataTable
        $table1.DataTable( {
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "bStateSave": true
        });
        
        
    } );
</script>

</body>
</html>